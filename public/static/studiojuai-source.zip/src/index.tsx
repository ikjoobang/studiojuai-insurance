import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { serveStatic } from 'hono/cloudflare-workers'
import { runAutoUpdate } from './auto-update'
import { syncSurgeryDataFromHIRA, searchSurgeryByName } from './hira-api'
import { searchSurgeryWithGPT } from './gpt-search'
import { searchAllInsuranceCompanies, convertToDBFormat } from './realtime-insurance-search'
import { hybridSearch } from './hybrid-search'

type Bindings = {
  DB: D1Database
  OPENAI_API_KEY: string
  PERPLEXITY_API_KEY: string
  HIRA_API_KEY: string
}

const app = new Hono<{ Bindings: Bindings }>()

// CORS 설정
app.use('/api/*', cors())

// 정적 파일 제공
app.use('/static/*', serveStatic({ root: './public' }))

// ==================== API 라우트 ====================

// 수술 검색 API
app.get('/api/search/surgery', async (c) => {
  const query = c.req.query('q')
  
  if (!query) {
    return c.json({ error: '검색어를 입력해주세요' }, 400)
  }

  try {
    // D1 데이터베이스가 없는 경우 빈 배열 반환
    if (!c.env.DB) {
      return c.json({ surgeries: [] })
    }
    
    const { results } = await c.env.DB.prepare(`
      SELECT id, name, name_en, edi_code, kcd_code, medical_classification, difficulty_level, description
      FROM surgeries
      WHERE name LIKE ? OR edi_code LIKE ? OR kcd_code LIKE ?
      ORDER BY name
      LIMIT 20
    `).bind(`%${query}%`, `%${query}%`, `%${query}%`).all()

    return c.json({ surgeries: results })
  } catch (error) {
    console.error('Search error:', error)
    return c.json({ surgeries: [] })
  }
})

// 수술 상세 정보 조회
app.get('/api/surgery/:id', async (c) => {
  const surgeryId = c.req.param('id')

  try {
    // D1 데이터베이스가 없는 경우
    if (!c.env.DB) {
      return c.json({ error: 'D1 데이터베이스가 설정되지 않았습니다' }, 503)
    }
    
    // 수술 기본 정보
    const surgery = await c.env.DB.prepare(`
      SELECT * FROM surgeries WHERE id = ?
    `).bind(surgeryId).first()

    if (!surgery) {
      return c.json({ error: '수술 정보를 찾을 수 없습니다' }, 404)
    }

    // 리스크 정보
    const risk = await c.env.DB.prepare(`
      SELECT * FROM surgery_risks WHERE surgery_id = ?
    `).bind(surgeryId).first()

    return c.json({ surgery, risk })
  } catch (error) {
    console.error('Fetch error:', error)
    return c.json({ error: '조회 중 오류가 발생했습니다' }, 500)
  }
})

// 보험사별 1-5종 수술비 특약 조회
app.get('/api/surgery/:id/type-benefits', async (c) => {
  const surgeryId = c.req.param('id')

  try {
    const { results } = await c.env.DB.prepare(`
      SELECT 
        ic.name as company_name,
        ic.code as company_code,
        stb.benefit_name,
        stb.surgery_type,
        stb.benefit_amount,
        stb.benefit_conditions
      FROM surgery_type_benefits stb
      JOIN insurance_companies ic ON stb.insurance_company_id = ic.id
      WHERE stb.surgery_id = ?
      ORDER BY ic.name
    `).bind(surgeryId).all()

    return c.json({ benefits: results })
  } catch (error) {
    console.error('Type benefits error:', error)
    return c.json({ error: '조회 중 오류가 발생했습니다' }, 500)
  }
})

// 보험사별 N대 수술비 특약 조회
app.get('/api/surgery/:id/n-benefits', async (c) => {
  const surgeryId = c.req.param('id')

  try {
    const { results } = await c.env.DB.prepare(`
      SELECT 
        ic.name as company_name,
        ic.code as company_code,
        nsb.total_n,
        nsb.benefit_structure,
        nsd.is_covered,
        nsd.sub_category,
        nsd.benefit_amount,
        nsd.notes
      FROM n_surgery_details nsd
      JOIN n_surgery_benefits nsb ON nsd.n_benefit_id = nsb.id
      JOIN insurance_companies ic ON nsb.insurance_company_id = ic.id
      WHERE nsd.surgery_id = ?
      ORDER BY ic.name
    `).bind(surgeryId).all()

    return c.json({ benefits: results })
  } catch (error) {
    console.error('N benefits error:', error)
    return c.json({ error: '조회 중 오류가 발생했습니다' }, 500)
  }
})

// 종합 분석 리포트 생성
app.get('/api/surgery/:id/report', async (c) => {
  const surgeryId = c.req.param('id')

  try {
    // 수술 기본 정보
    const surgery = await c.env.DB.prepare(`
      SELECT * FROM surgeries WHERE id = ?
    `).bind(surgeryId).first()

    if (!surgery) {
      return c.json({ error: '수술 정보를 찾을 수 없습니다' }, 404)
    }

    // 1-5종 특약 정보
    const { results: typeBenefits } = await c.env.DB.prepare(`
      SELECT 
        ic.name as company_name,
        ic.code as company_code,
        stb.benefit_name,
        stb.surgery_type,
        stb.benefit_amount,
        stb.benefit_conditions
      FROM surgery_type_benefits stb
      JOIN insurance_companies ic ON stb.insurance_company_id = ic.id
      WHERE stb.surgery_id = ?
      ORDER BY ic.name
    `).bind(surgeryId).all()

    // N대 특약 정보
    const { results: nBenefits } = await c.env.DB.prepare(`
      SELECT 
        ic.name as company_name,
        ic.code as company_code,
        nsb.total_n,
        nsb.benefit_structure,
        nsd.is_covered,
        nsd.sub_category,
        nsd.benefit_amount,
        nsd.notes
      FROM n_surgery_details nsd
      JOIN n_surgery_benefits nsb ON nsd.n_benefit_id = nsb.id
      JOIN insurance_companies ic ON nsb.insurance_company_id = ic.id
      WHERE nsd.surgery_id = ?
      ORDER BY ic.name
    `).bind(surgeryId).all()

    // 리스크 정보
    const risk = await c.env.DB.prepare(`
      SELECT * FROM surgery_risks WHERE surgery_id = ?
    `).bind(surgeryId).first()

    // 검색 로그 업데이트
    // 기존 로그 확인
    const existingLog = await c.env.DB.prepare(`
      SELECT id, search_count FROM search_logs WHERE surgery_name = ?
    `).bind(surgery.name).first()
    
    if (existingLog) {
      // 기존 로그 업데이트
      await c.env.DB.prepare(`
        UPDATE search_logs 
        SET search_count = ?, last_searched_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).bind(existingLog.search_count + 1, existingLog.id).run()
    } else {
      // 새 로그 생성
      await c.env.DB.prepare(`
        INSERT INTO search_logs (surgery_name, surgery_code, search_count, last_searched_at)
        VALUES (?, ?, 1, CURRENT_TIMESTAMP)
      `).bind(surgery.name, surgery.edi_code).run()
    }

    return c.json({
      surgery,
      typeBenefits,
      nBenefits,
      risk,
      generatedAt: new Date().toISOString()
    })
  } catch (error) {
    console.error('Report error:', error)
    return c.json({ error: '리포트 생성 중 오류가 발생했습니다' }, 500)
  }
})

// 보험사 목록 조회
app.get('/api/insurance-companies', async (c) => {
  try {
    // D1 데이터베이스가 없는 경우 빈 배열 반환
    if (!c.env.DB) {
      return c.json({ companies: [] })
    }
    
    const { results } = await c.env.DB.prepare(`
      SELECT * FROM insurance_companies ORDER BY name
    `).all()

    return c.json({ companies: results })
  } catch (error) {
    console.error('Companies error:', error)
    return c.json({ companies: [] })
  }
})

// 수술 데이터 추가 (관리자용)
app.post('/api/admin/surgery', async (c) => {
  try {
    const data = await c.req.json()
    const { name, name_en, edi_code, kcd_code, medical_classification, difficulty_level, description } = data

    const result = await c.env.DB.prepare(`
      INSERT INTO surgeries (name, name_en, edi_code, kcd_code, medical_classification, difficulty_level, description)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).bind(name, name_en, edi_code, kcd_code, medical_classification, difficulty_level, description).run()

    return c.json({ success: true, id: result.meta.last_row_id })
  } catch (error) {
    console.error('Insert error:', error)
    return c.json({ error: '추가 중 오류가 발생했습니다' }, 500)
  }
})

// 1-5종 특약 데이터 추가 (관리자용)
app.post('/api/admin/type-benefit', async (c) => {
  try {
    const data = await c.req.json()
    const { insurance_company_id, surgery_id, benefit_name, surgery_type, benefit_amount, benefit_conditions } = data

    const result = await c.env.DB.prepare(`
      INSERT INTO surgery_type_benefits 
      (insurance_company_id, surgery_id, benefit_name, surgery_type, benefit_amount, benefit_conditions)
      VALUES (?, ?, ?, ?, ?, ?)
    `).bind(insurance_company_id, surgery_id, benefit_name, surgery_type, benefit_amount, benefit_conditions).run()

    return c.json({ success: true, id: result.meta.last_row_id })
  } catch (error) {
    console.error('Insert error:', error)
    return c.json({ error: '추가 중 오류가 발생했습니다' }, 500)
  }
})

// N대 특약 상세 추가 (관리자용)
app.post('/api/admin/n-benefit-detail', async (c) => {
  try {
    const data = await c.req.json()
    const { n_benefit_id, surgery_id, is_covered, sub_category, benefit_amount, notes } = data

    const result = await c.env.DB.prepare(`
      INSERT INTO n_surgery_details 
      (n_benefit_id, surgery_id, is_covered, sub_category, benefit_amount, notes)
      VALUES (?, ?, ?, ?, ?, ?)
    `).bind(n_benefit_id, surgery_id, is_covered, sub_category, benefit_amount, notes).run()

    return c.json({ success: true, id: result.meta.last_row_id })
  } catch (error) {
    console.error('Insert error:', error)
    return c.json({ error: '추가 중 오류가 발생했습니다' }, 500)
  }
})

// 인기 검색어 조회
app.get('/api/popular-searches', async (c) => {
  try {
    // D1 데이터베이스가 없는 경우 빈 배열 반환
    if (!c.env.DB) {
      return c.json({ searches: [] })
    }
    
    const { results } = await c.env.DB.prepare(`
      SELECT surgery_name, surgery_code, search_count, last_searched_at
      FROM search_logs
      ORDER BY search_count DESC, last_searched_at DESC
      LIMIT 10
    `).all()

    return c.json({ searches: results })
  } catch (error) {
    console.error('Popular searches error:', error)
    // 에러 발생 시에도 빈 배열 반환 (500 에러 방지)
    return c.json({ searches: [] })
  }
})

// ==================== 보험 보장 내역 편집/저장 API ====================

// 보장 내역 조회 (D1에서 저장된 데이터 우선)
app.get('/api/coverage/search', async (c) => {
  const surgeryName = c.req.query('surgery')
  
  if (!surgeryName) {
    return c.json({ error: '수술명을 입력해주세요' }, 400)
  }

  try {
    if (!c.env.DB) {
      return c.json({ coverages: [] })
    }
    
    // D1에서 저장된 보장 내역 조회
    const { results } = await c.env.DB.prepare(`
      SELECT 
        id,
        surgery_name,
        surgery_code,
        company_name,
        coverage_amount,
        coverage_options,
        coverage_type,
        source_url,
        notes,
        verified,
        updated_at
      FROM insurance_coverage
      WHERE surgery_name = ?
      ORDER BY company_name
    `).bind(surgeryName).all()

    return c.json({ 
      coverages: results,
      fromDatabase: results.length > 0
    })
  } catch (error) {
    console.error('Coverage search error:', error)
    return c.json({ coverages: [], error: '조회 중 오류가 발생했습니다' }, 500)
  }
})

// 보장 내역 저장/수정
app.post('/api/coverage/save', async (c) => {
  try {
    if (!c.env.DB) {
      return c.json({ error: 'D1 데이터베이스가 설정되지 않았습니다' }, 503)
    }

    const data = await c.req.json()
    const {
      id,
      surgery_name,
      surgery_code,
      company_name,
      coverage_amount,
      coverage_options,
      coverage_type,
      source_url,
      notes,
      updated_by,
      verified
    } = data

    // 필수 필드 검증
    if (!surgery_name || !company_name || !coverage_amount) {
      return c.json({ error: '필수 항목을 입력해주세요' }, 400)
    }

    if (id) {
      // 기존 데이터 업데이트
      await c.env.DB.prepare(`
        UPDATE insurance_coverage
        SET surgery_name = ?,
            surgery_code = ?,
            company_name = ?,
            coverage_amount = ?,
            coverage_options = ?,
            coverage_type = ?,
            source_url = ?,
            notes = ?,
            updated_by = ?,
            verified = ?,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).bind(
        surgery_name,
        surgery_code || null,
        company_name,
        coverage_amount,
        coverage_options || null,
        coverage_type || null,
        source_url || null,
        notes || null,
        updated_by || null,
        verified ? 1 : 0,
        id
      ).run()

      return c.json({ success: true, id, message: '수정되었습니다' })
    } else {
      // 신규 데이터 삽입
      const result = await c.env.DB.prepare(`
        INSERT INTO insurance_coverage (
          surgery_name, surgery_code, company_name, coverage_amount,
          coverage_options, coverage_type, source_url, notes,
          updated_by, verified
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(
        surgery_name,
        surgery_code || null,
        company_name,
        coverage_amount,
        coverage_options || null,
        coverage_type || null,
        source_url || null,
        notes || null,
        updated_by || null,
        verified ? 1 : 0
      ).run()

      return c.json({ 
        success: true, 
        id: result.meta.last_row_id,
        message: '저장되었습니다'
      })
    }
  } catch (error) {
    console.error('Coverage save error:', error)
    return c.json({ error: '저장 중 오류가 발생했습니다' }, 500)
  }
})

// 보장 내역 삭제
app.delete('/api/coverage/:id', async (c) => {
  const id = c.req.param('id')

  try {
    if (!c.env.DB) {
      return c.json({ error: 'D1 데이터베이스가 설정되지 않았습니다' }, 503)
    }

    await c.env.DB.prepare(`
      DELETE FROM insurance_coverage WHERE id = ?
    `).bind(id).run()

    return c.json({ success: true, message: '삭제되었습니다' })
  } catch (error) {
    console.error('Coverage delete error:', error)
    return c.json({ error: '삭제 중 오류가 발생했습니다' }, 500)
  }
})

// GPT 결과를 D1에 일괄 저장
app.post('/api/coverage/bulk-save', async (c) => {
  try {
    if (!c.env.DB) {
      return c.json({ error: 'D1 데이터베이스가 설정되지 않았습니다' }, 503)
    }

    const { coverages } = await c.req.json()
    
    if (!Array.isArray(coverages) || coverages.length === 0) {
      return c.json({ error: '저장할 데이터가 없습니다' }, 400)
    }

    let savedCount = 0
    
    for (const item of coverages) {
      const { surgery_name, surgery_code, company_name, coverage_amount, coverage_options, coverage_type } = item
      
      if (!surgery_name || !company_name || !coverage_amount) {
        continue
      }

      try {
        await c.env.DB.prepare(`
          INSERT INTO insurance_coverage (
            surgery_name, surgery_code, company_name, coverage_amount,
            coverage_options, coverage_type, verified
          ) VALUES (?, ?, ?, ?, ?, ?, 0)
        `).bind(
          surgery_name,
          surgery_code || null,
          company_name,
          coverage_amount,
          coverage_options || null,
          coverage_type || null
        ).run()
        
        savedCount++
      } catch (err) {
        console.error(`Failed to save ${company_name}:`, err)
      }
    }

    return c.json({ 
      success: true, 
      savedCount,
      message: `${savedCount}개 항목이 저장되었습니다`
    })
  } catch (error) {
    console.error('Bulk save error:', error)
    return c.json({ error: '일괄 저장 중 오류가 발생했습니다' }, 500)
  }
})

// ==================== 프론트엔드 페이지 ====================

app.get('/', (c) => {
  return c.html(`
    <!DOCTYPE html>
    <html lang="ko">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Studiojiai_ - 보험 수술비 특약 분석 시스템</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
        <link href="/static/styles.css" rel="stylesheet">
        <style>
          /* 기본 스타일 강제 적용 */
          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
          }
          
          html, body {
            width: 100%;
            height: 100%;
            background-color: #f9fafb !important;
            color: #111827 !important;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif !important;
          }
          
          /* 반응형 타이포그래피 - 모바일: 글씨 크고 + 줄간격 넓게 */
          @media (max-width: 768px) {
            body { 
              font-size: 18px !important; 
              line-height: 1.9 !important; 
              letter-spacing: -0.01em !important; 
            }
            .result-content p {
              margin-bottom: 1.5rem !important;
            }
            .result-content ul, .result-content ol {
              margin-bottom: 1.8rem !important;
            }
          }
          
          /* 반응형 타이포그래피 - PC: 가로폭 제한 + 밀도 높게 */
          @media (min-width: 769px) {
            body { 
              font-size: 16px !important; 
              line-height: 1.6 !important; 
              letter-spacing: -0.01em !important; 
            }
            .result-content {
              max-width: 720px !important;
              margin: 0 auto !important;
            }
            .result-content p {
              margin-bottom: 1rem !important;
            }
            .result-content ul, .result-content ol {
              margin-bottom: 1.2rem !important;
            }
          }
          
          /* 확실하게 보이도록 - 모든 텍스트 검정색 */
          h1, h2, h3, h4, h5, h6, p, a, button, input, label, span, div {
            color: #111827 !important;
            visibility: visible !important;
            opacity: 1 !important;
          }
          
          /* 버튼 텍스트도 명확하게 */
          button {
            color: #ffffff !important;
          }
          
          /* 문단 간격 활용 */
          .result-content p {
            margin-bottom: 1.2rem;
          }
          
          .result-content h3, .result-content h4, .result-content h5 {
            margin-top: 2rem;
            margin-bottom: 1rem;
            font-weight: 700;
          }
          
          /* 볼드 + 이탤릭 혼용 */
          .result-content strong {
            font-weight: 700;
            color: #1f2937;
          }
          
          .result-content em {
            font-style: italic;
            color: #4b5563;
          }
          
          .result-content a {
            color: #03C75A !important;
            text-decoration: underline;
          }
          
          /* 불렛 포인트 스타일 */
          .result-content ul, .result-content ol {
            margin-left: 1.5rem;
            margin-bottom: 1.2rem;
          }
          
          .result-content li {
            margin-bottom: 0.5rem;
            line-height: 1.6;
          }
          
          /* 짧은 문장 강조 */
          .result-content .short-sentence {
            display: block;
            margin-bottom: 0.8rem;
            font-size: 0.95em;
            line-height: 1.5;
          }
        </style>
    </head>
    <body class="bg-gray-50">
        <!-- 헤더 -->
        <header class="bg-white shadow-sm border-b">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
                <div class="flex items-center justify-between flex-wrap gap-4">
                    <div class="flex items-center space-x-3">
                        <i class="fas fa-hospital-user text-3xl text-blue-600"></i>
                        <div>
                            <h1 class="text-xl md:text-2xl font-bold text-gray-900">Studiojuai_Insurance</h1>
                            <p class="text-xs md:text-sm text-gray-500">보험 수술비 특약 분석 시스템</p>
                        </div>
                    </div>
                    <div class="flex items-center gap-3 flex-wrap">
                        <button onclick="toggleDarkMode()" class="text-2xl hover:scale-110 transition-transform" title="다크모드 전환">
                            <span id="darkModeIcon">🌙</span>
                        </button>
                        <button onclick="showAdminPanel()" class="text-xs md:text-sm text-gray-600 hover:text-gray-900 px-3 py-2 rounded-lg border border-gray-300 hover:bg-gray-50 transition-colors">
                            <i class="fas fa-cog mr-1"></i>관리자
                        </button>
                    </div>
                </div>
            </div>
        </header>

        <!-- 메인 컨텐츠 -->
        <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <!-- ICD-10 진단코드 검색 영역 (최상단) -->
            <div class="bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 rounded-2xl shadow-xl p-8 mb-8 border-2 border-blue-400">
                <div class="text-center mb-6">
                    <h2 class="text-3xl md:text-4xl font-black text-gray-900 mb-3 flex items-center justify-center gap-3">
                        <i class="fas fa-stethoscope text-blue-600"></i>
                        ICD-10 진단코드 검색
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-bold bg-blue-500 text-white">
                            정확도 100%
                        </span>
                    </h2>
                    <p class="text-base md:text-lg text-gray-600 font-medium">
                        🏥 병원 진단서에 표기되는 실제 질병분류코드 검색 (H25, I21, M17 등)
                    </p>
                    <p class="text-sm text-blue-700 mt-2 font-semibold">
                        ✨ 백내장(H25), 심근경색(I21), 뇌경색(I63), 무릎관절증(M17) 등 실제 의료 코드
                    </p>
                </div>
                
                <div class="flex flex-col md:flex-row items-center gap-4">
                    <div class="flex-1 w-full">
                        <input 
                            type="text" 
                            id="dbSearchInput"
                            placeholder="예: 백내장, H25, 심근경색, I21, 뇌경색, 당뇨병"
                            class="w-full px-6 py-5 text-lg border-2 border-blue-300 rounded-xl focus:ring-4 focus:ring-blue-300 focus:border-blue-500 transition-all shadow-lg"
                            onkeypress="if(event.key==='Enter') searchFromDB()"
                            oninput="showDBSuggestions(this.value)"
                        >
                    </div>
                    <button 
                        onclick="searchFromDB()"
                        class="w-full md:w-auto px-8 py-5 bg-gradient-to-r from-blue-500 to-indigo-600 text-white text-lg font-bold rounded-xl hover:from-blue-600 hover:to-indigo-700 transition-all shadow-lg hover:shadow-2xl transform hover:scale-105"
                    >
                        <i class="fas fa-search mr-2"></i>진단코드 검색
                    </button>
                </div>
                
                <!-- 자동완성 제안 -->
                <div id="dbSuggestions" class="mt-4 hidden bg-white rounded-lg shadow-lg border-2 border-blue-200 max-h-60 overflow-y-auto"></div>
                
                <!-- ICD 진단코드 검색 결과 -->
                <div id="dbSearchResults" class="mt-4 hidden"></div>
                
                <div class="mt-6 text-center">
                    <p class="text-sm text-gray-500">
                        💡 <strong>ICD-10 진단코드</strong>는 실제 병원 진단서, 처방전, 입원기록에 표기되는 질병 분류 코드입니다. 
                        보험 청구 시 진단서에서 이 코드를 확인하세요.
                    </p>
                </div>
            </div>

            <!-- AI 보험 분석 검색 영역 -->
            <div class="bg-gradient-to-br from-orange-50 via-red-50 to-pink-50 rounded-2xl shadow-xl p-8 mb-8 border-2 border-orange-300">
                <div class="text-center mb-6">
                    <h2 class="text-3xl md:text-4xl font-black text-gray-900 mb-3 flex items-center justify-center gap-3">
                        <i class="fas fa-robot text-orange-600 animate-pulse"></i>
                        AI 진단코드 보험 분석 검색
                        <span class="text-2xl md:text-3xl text-orange-600">(Studioju_AI)</span>
                    </h2>
                    <p class="text-base md:text-lg text-gray-600 font-medium">
                        🔍 진단코드나 질병명을 입력하면 AI가 11개 보험사 특약을 자동 분석합니다
                    </p>
                    <p class="text-sm text-orange-700 mt-2 font-semibold">
                        💡 1-5종 수술비 특약 + N대 수술비 세부등급 분석 (27대, 59대, 43대 등)
                    </p>
                </div>
                
                <div class="flex flex-col md:flex-row items-center gap-4">
                    <div class="flex-1 w-full">
                        <input 
                            type="text" 
                            id="searchInput"
                            placeholder="예: H40.1, 원발개방각녹내장, H25 백내장, I21 심근경색"
                            class="w-full px-6 py-5 text-lg border-2 border-orange-300 rounded-xl focus:ring-4 focus:ring-orange-300 focus:border-orange-500 transition-all shadow-lg"
                            onkeypress="if(event.key==='Enter') searchWithGPT()"
                        >
                    </div>
                    <button 
                        onclick="searchWithGPT()"
                        class="w-full md:w-auto px-8 py-5 bg-gradient-to-r from-orange-500 to-red-600 text-white text-lg font-bold rounded-xl hover:from-orange-600 hover:to-red-700 transition-all shadow-lg hover:shadow-2xl transform hover:scale-105"
                    >
                        <i class="fas fa-robot mr-2"></i>AI 보험 분석 시작
                    </button>
                </div>
                
                <!-- 검색 결과 드롭다운 -->
                <div id="searchResults" class="mt-4 hidden"></div>
                
                <!-- 다운로드 버튼 (검색 결과가 있을 때만 표시) -->
                <div id="downloadButtons" class="mt-4 hidden">
                    <div class="flex gap-3 justify-center">
                        <button onclick="downloadAsPDF()" class="px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-all shadow-lg flex items-center gap-2">
                            <i class="fas fa-file-pdf"></i>
                            PDF 다운로드
                        </button>
                        <button onclick="downloadAsTXT()" class="px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-all shadow-lg flex items-center gap-2">
                            <i class="fas fa-file-alt"></i>
                            TXT 다운로드
                        </button>
                    </div>
                </div>
            </div>

            <!-- Studiojuai 프로젝트 링크 -->
            <div class="bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg shadow-md p-6 mb-6 border-2 border-purple-200">
                <h3 class="text-lg font-bold text-gray-900 mb-4 flex items-center">
                    <i class="fas fa-star text-yellow-500 mr-2"></i>Studiojuai 프로젝트
                </h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <!-- 의료 영상 판독 -->
                    <button onclick="openProjectModal('https://medical-report-analyzer-ten.vercel.app/', 'Studiojuai - 의료 영상 판독')" 
                            class="bg-white hover:bg-blue-50 border-2 border-blue-300 rounded-lg p-4 text-left transition-all hover:shadow-lg group">
                        <div class="flex items-center gap-3 mb-2">
                            <i class="fas fa-x-ray text-blue-600 text-2xl group-hover:scale-110 transition-transform"></i>
                            <div>
                                <h4 class="font-bold text-gray-900 text-sm">Studiojuai</h4>
                                <p class="text-xs text-gray-600">의료 영상 판독</p>
                            </div>
                        </div>
                        <p class="text-xs text-gray-500 mt-2">AI 기반 의료 영상 분석 시스템</p>
                    </button>

                    <!-- 암호화폐 분석 -->
                    <button onclick="openProjectModal('https://studiojuai-crypto.bolt.host/', '고급 암호화폐 분석 및 가격 예측 플랫폼')" 
                            class="bg-white hover:bg-green-50 border-2 border-green-300 rounded-lg p-4 text-left transition-all hover:shadow-lg group">
                        <div class="flex items-center gap-3 mb-2">
                            <i class="fas fa-bitcoin text-green-600 text-2xl group-hover:scale-110 transition-transform"></i>
                            <div>
                                <h4 class="font-bold text-gray-900 text-sm">Studiojuai</h4>
                                <p class="text-xs text-gray-600">암호화폐 분석</p>
                            </div>
                        </div>
                        <p class="text-xs text-gray-500 mt-2">AI 기반 암호화폐 가격 예측</p>
                    </button>

                    <!-- 타로 -->
                    <button onclick="openProjectModal('https://studioju-tarot.pages.dev/', 'Studiojuai_Tarot_타로')" 
                            class="bg-white hover:bg-purple-50 border-2 border-purple-300 rounded-lg p-4 text-left transition-all hover:shadow-lg group">
                        <div class="flex items-center gap-3 mb-2">
                            <i class="fas fa-star-and-crescent text-purple-600 text-2xl group-hover:scale-110 transition-transform"></i>
                            <div>
                                <h4 class="font-bold text-gray-900 text-sm">Studiojuai</h4>
                                <p class="text-xs text-gray-600">타로 리딩</p>
                            </div>
                        </div>
                        <p class="text-xs text-gray-500 mt-2">AI 기반 타로 카드 리딩</p>
                    </button>
                </div>
            </div>

            <!-- 인기 검색어 -->
            <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">
                    <i class="fas fa-fire text-orange-500 mr-2"></i>인기 검색 수술
                </h3>
                <div id="popularSearches" class="flex flex-wrap gap-2">
                    <div class="text-gray-500">로딩 중...</div>
                </div>
            </div>

            <!-- 보험/유관기관 링크 -->
            <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">
                    <i class="fas fa-link text-blue-600 mr-2"></i>빠른 링크
                </h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <!-- 보험기관 -->
                    <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                        <button onclick="toggleOrgSection('insurance')" class="w-full text-left flex items-center justify-between">
                            <div class="flex items-center gap-2">
                                <i class="fas fa-building text-blue-600"></i>
                                <span class="font-semibold">보험기관</span>
                                <span class="text-xs text-gray-500" id="insuranceCount"></span>
                            </div>
                            <i class="fas fa-chevron-down" id="insuranceChevron"></i>
                        </button>
                        <div id="insuranceOrgs" class="hidden mt-3 space-y-2 max-h-96 overflow-y-auto"></div>
                    </div>

                    <!-- 유관기관 -->
                    <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                        <button onclick="toggleOrgSection('related')" class="w-full text-left flex items-center justify-between">
                            <div class="flex items-center gap-2">
                                <i class="fas fa-university text-green-600"></i>
                                <span class="font-semibold">유관기관</span>
                                <span class="text-xs text-gray-500" id="relatedCount"></span>
                            </div>
                            <i class="fas fa-chevron-down" id="relatedChevron"></i>
                        </button>
                        <div id="relatedOrgs" class="hidden mt-3 space-y-2 max-h-96 overflow-y-auto"></div>
                    </div>

                    <!-- 해외보험기관 -->
                    <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                        <button onclick="toggleOrgSection('overseas')" class="w-full text-left flex items-center justify-between">
                            <div class="flex items-center gap-2">
                                <i class="fas fa-globe text-purple-600"></i>
                                <span class="font-semibold">해외보험기관</span>
                                <span class="text-xs text-gray-500" id="overseasCount"></span>
                            </div>
                            <i class="fas fa-chevron-down" id="overseasChevron"></i>
                        </button>
                        <div id="overseasOrgs" class="hidden mt-3 space-y-2 max-h-96 overflow-y-auto"></div>
                    </div>
                </div>
            </div>

            <!-- 분석 결과 영역 -->
            <div id="analysisResult" class="hidden">
                <!-- 수술 기본 정보 -->
                <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                    <div class="flex items-center justify-between mb-4">
                        <h2 class="text-xl font-bold text-gray-900">
                            <i class="fas fa-info-circle text-blue-600 mr-2"></i>수술 기본 정보
                        </h2>
                        <button onclick="downloadReport()" class="text-sm text-blue-600 hover:text-blue-800">
                            <i class="fas fa-download mr-1"></i>리포트 다운로드
                        </button>
                    </div>
                    <div id="surgeryInfo"></div>
                </div>

                <!-- 1-5종 수술비 특약 -->
                <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                    <h2 class="text-xl font-bold text-gray-900 mb-4">
                        <i class="fas fa-list-ol text-green-600 mr-2"></i>1-5종 수술비 특약 보장 현황
                    </h2>
                    <div id="typeBenefits"></div>
                </div>

                <!-- N대 수술비 특약 -->
                <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                    <h2 class="text-xl font-bold text-gray-900 mb-4">
                        <i class="fas fa-hospital text-purple-600 mr-2"></i>N대 수술비 특약 세부등급 보장 현황
                    </h2>
                    <div id="nBenefits"></div>
                </div>

                <!-- 리스크 정보 -->
                <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                    <h2 class="text-xl font-bold text-gray-900 mb-4">
                        <i class="fas fa-exclamation-triangle text-yellow-600 mr-2"></i>가능성 정보 (리스크 대비)
                    </h2>
                    <div id="riskInfo"></div>
                </div>

                <!-- 고객 상담 포인트 -->
                <div class="bg-blue-50 rounded-lg p-6">
                    <h2 class="text-xl font-bold text-gray-900 mb-4">
                        <i class="fas fa-comments text-blue-600 mr-2"></i>고객 상담 포인트
                    </h2>
                    <div id="consultingPoints"></div>
                </div>
            </div>
        </main>

        <!-- 프로젝트 iframe 모달 -->
        <div id="projectModal" class="hidden fixed inset-0 bg-black bg-opacity-75 z-50 flex items-center justify-center p-4">
            <div class="bg-white rounded-lg shadow-2xl w-full h-full max-w-7xl max-h-[90vh] flex flex-col">
                <div class="flex items-center justify-between p-4 border-b bg-gray-50">
                    <h2 class="text-xl font-bold text-gray-900 flex items-center">
                        <i class="fas fa-external-link-alt text-blue-600 mr-2"></i>
                        <span id="projectModalTitle">프로젝트</span>
                    </h2>
                    <button onclick="closeProjectModal()" class="text-gray-500 hover:text-gray-700 transition-colors">
                        <i class="fas fa-times text-2xl"></i>
                    </button>
                </div>
                <div class="flex-1 overflow-hidden">
                    <iframe id="projectIframe" class="w-full h-full border-0" sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox"></iframe>
                </div>
            </div>
        </div>

        <!-- PDF 업로드 모달 -->
        <div id="pdfUploadModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
            <div class="bg-white rounded-lg shadow-xl p-8 max-w-3xl w-full mx-4 max-h-[90vh] overflow-y-auto">
                <div class="flex items-center justify-between mb-6">
                    <h2 class="text-2xl font-bold text-gray-900">
                        <i class="fas fa-file-pdf text-red-600 mr-2"></i>보험사 약관 PDF 업로드
                    </h2>
                    <button onclick="closePDFUpload()" class="text-gray-500 hover:text-gray-700">
                        <i class="fas fa-times text-2xl"></i>
                    </button>
                </div>

                <div class="bg-blue-50 p-4 rounded-lg mb-6">
                    <h3 class="font-bold text-blue-900 mb-2">
                        <i class="fas fa-info-circle mr-2"></i>사용 방법
                    </h3>
                    <ol class="text-sm text-blue-800 space-y-1">
                        <li>1. 보험사 선택</li>
                        <li>2. 보험사 약관 PDF 파일 업로드 (N대 수술비 특약 포함)</li>
                        <li>3. AI가 PDF를 분석하여 수술 코드별 보험 등급 추출</li>
                        <li>4. 추출된 정보를 diagnosis-codes.json에 자동 저장</li>
                    </ol>
                </div>

                <div class="space-y-4">
                    <!-- 보험사 선택 -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">보험사 선택</label>
                        <select id="insuranceCompanySelect" class="w-full px-4 py-3 border rounded-lg">
                            <option value="">보험사를 선택하세요</option>
                            <option value="삼성화재">삼성화재 (111대)</option>
                            <option value="현대해상">현대해상 (119대)</option>
                            <option value="DB손보">DB손보 (119대)</option>
                            <option value="KB손보">KB손보 (112대)</option>
                            <option value="농협손보">농협손보 (144대)</option>
                            <option value="한화손보">한화손보 (124대)</option>
                            <option value="메리츠화재">메리츠화재 (119대)</option>
                            <option value="동부손보">동부손보 (119대)</option>
                            <option value="롯데손보">롯데손보 (112대)</option>
                            <option value="흥국화재">흥국화재 (112대)</option>
                            <option value="MG손보">MG손보 (119대)</option>
                        </select>
                    </div>

                    <!-- PDF 파일 업로드 -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">PDF 파일 업로드</label>
                        <input type="file" id="pdfFileInput" accept=".pdf" class="w-full px-4 py-3 border rounded-lg">
                        <p class="text-xs text-gray-500 mt-1">PDF 파일만 업로드 가능합니다</p>
                    </div>

                    <!-- 업로드 버튼 -->
                    <button onclick="uploadAndAnalyzePDF()" class="w-full px-6 py-4 bg-red-600 text-white rounded-lg hover:bg-red-700 font-bold">
                        <i class="fas fa-upload mr-2"></i>PDF 업로드 및 분석 시작
                    </button>

                    <!-- 진행 상태 -->
                    <div id="pdfAnalysisProgress" class="hidden">
                        <div class="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded">
                            <div class="flex items-start">
                                <i class="fas fa-spinner fa-spin text-yellow-600 text-2xl mr-3 mt-1"></i>
                                <div class="flex-1">
                                    <h4 class="font-bold text-yellow-900 mb-2">PDF 분석 중...</h4>
                                    <p id="pdfAnalysisStatus" class="text-sm text-yellow-800">PDF를 업로드하는 중입니다...</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 분석 결과 -->
                    <div id="pdfAnalysisResult" class="hidden"></div>
                </div>
            </div>
        </div>

        <!-- 관리자 패널 모달 -->
        <div id="adminModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
            <div class="bg-white rounded-lg shadow-xl p-8 max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
                <div class="flex items-center justify-between mb-6">
                    <h2 class="text-2xl font-bold text-gray-900">
                        <i class="fas fa-cog text-blue-600 mr-2"></i>관리자 패널
                    </h2>
                    <button onclick="closeAdminPanel()" class="text-gray-500 hover:text-gray-700">
                        <i class="fas fa-times text-2xl"></i>
                    </button>
                </div>

                <div class="space-y-4">
                    <button onclick="showPDFUpload()" class="w-full px-4 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700">
                        <i class="fas fa-file-pdf mr-2"></i>PDF 업로드 (보험 약관 분석)
                    </button>
                    <button onclick="syncHIRAData()" class="w-full px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                        <i class="fas fa-database mr-2"></i>HIRA 동기화
                    </button>
                    <button onclick="triggerAutoUpdate()" class="w-full px-4 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700">
                        <i class="fas fa-sync-alt mr-2"></i>자동 업데이트
                    </button>
                    <button onclick="showAddSurgery()" class="w-full px-4 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700">
                        <i class="fas fa-plus mr-2"></i>수술 정보 추가
                    </button>
                    <button onclick="viewStats()" class="w-full px-4 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700">
                        <i class="fas fa-chart-bar mr-2"></i>통계 보기
                    </button>
                </div>
            </div>
        </div>

        <!-- 푸터 -->
        <footer class="footer mt-20 pt-8 border-t border-gray-200">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="text-center">
                    <div class="footer-logo mb-4">
                        <h3 class="text-xl font-bold">Studiojuai_Insurance</h3>
                    </div>
                    
                    <div class="footer-links mb-4 flex justify-center gap-6">
                        <a href="https://www.studiojuai.com" target="_blank" rel="noopener noreferrer" class="hover:text-green-600 transition-colors">
                            <i class="fas fa-globe mr-1"></i>Website
                        </a>
                        <a href="https://www.instagram.com/STUDIO_JU_AI" target="_blank" rel="noopener noreferrer" class="hover:text-pink-600 transition-colors">
                            <i class="fab fa-instagram mr-1"></i>@STUDIO_JU_AI
                        </a>
                        <a href="mailto:ikjoobang@gmail.com" class="hover:text-blue-600 transition-colors">
                            <i class="fas fa-envelope mr-1"></i>Contact
                        </a>
                    </div>
                    
                    <div class="text-sm text-gray-500">
                        <p>© 2025. ALL RIGHTS RESERVED.</p>
                    </div>
                </div>
            </div>
        </footer>

        <script src="/static/app.js"></script>
    </body>
    </html>
  `)
})

// ==================== 자동 업데이트 API ====================

// 수동 업데이트 트리거 (관리자용)
app.post('/api/admin/auto-update', async (c) => {
  try {
    const { company_url, company_code } = await c.req.json()
    
    if (!company_url || !company_code) {
      return c.json({ error: '보험사 URL과 코드를 입력해주세요' }, 400)
    }
    
    const result = await runAutoUpdate(
      {
        DB: c.env.DB,
        OPENAI_API_KEY: c.env.OPENAI_API_KEY
      },
      company_url,
      company_code
    )
    
    return c.json(result)
  } catch (error) {
    console.error('Auto-update API error:', error)
    return c.json({ 
      success: false, 
      error: error instanceof Error ? error.message : String(error) 
    }, 500)
  }
})

// 업데이트 상태 조회
app.get('/api/admin/update-status', async (c) => {
  try {
    // 최근 업데이트 통계
    const stats = await c.env.DB.prepare(`
      SELECT 
        COUNT(DISTINCT id) as total_surgeries,
        COUNT(DISTINCT CASE WHEN updated_at > datetime('now', '-7 days') THEN id END) as updated_this_week,
        MAX(updated_at) as last_update
      FROM surgeries
    `).first()
    
    return c.json({ stats })
  } catch (error) {
    console.error('Status error:', error)
    return c.json({ error: '조회 중 오류가 발생했습니다' }, 500)
  }
})

// ==================== HIRA 공공데이터 API 연동 ====================

// HIRA API로 수술 코드 동기화
app.post('/api/admin/hira-sync', async (c) => {
  try {
    const apiKey = c.env.HIRA_API_KEY
    
    if (!apiKey || apiKey === 'YOUR_API_KEY_HERE') {
      return c.json({ 
        error: 'HIRA API 키가 설정되지 않았습니다. .dev.vars 파일에서 HIRA_API_KEY를 설정해주세요.' 
      }, 400)
    }

    console.log('HIRA API 동기화 시작...')
    const result = await syncSurgeryDataFromHIRA(apiKey, c.env.DB)
    
    return c.json({
      success: true,
      message: 'HIRA API 동기화 완료',
      total: result.total,
      saved: result.saved
    })
  } catch (error) {
    console.error('HIRA sync error:', error)
    return c.json({ 
      error: 'HIRA API 동기화 중 오류가 발생했습니다',
      details: error instanceof Error ? error.message : String(error)
    }, 500)
  }
})

// HIRA API에서 수술 검색 (실시간)
app.get('/api/admin/hira-search', async (c) => {
  const query = c.req.query('q')
  
  if (!query) {
    return c.json({ error: '검색어를 입력해주세요' }, 400)
  }

  try {
    const apiKey = c.env.HIRA_API_KEY
    
    if (!apiKey || apiKey === 'YOUR_API_KEY_HERE') {
      return c.json({ 
        error: 'HIRA API 키가 설정되지 않았습니다.' 
      }, 400)
    }

    const results = await searchSurgeryByName(apiKey, query)
    
    return c.json({
      success: true,
      count: results.length,
      results: results
    })
  } catch (error) {
    console.error('HIRA search error:', error)
    return c.json({ 
      error: 'HIRA API 검색 중 오류가 발생했습니다',
      details: error instanceof Error ? error.message : String(error)
    }, 500)
  }
})

// ==================== PDF 분석 및 저장 API ====================

// PDF 업로드 및 분석
app.post('/api/admin/analyze-pdf', async (c) => {
  try {
    const formData = await c.req.formData()
    const company = formData.get('company') as string
    const file = formData.get('file') as File

    if (!company || !file) {
      return c.json({ error: '보험사와 PDF 파일을 모두 제공해주세요' }, 400)
    }

    const apiKey = c.env.OPENAI_API_KEY
    if (!apiKey) {
      return c.json({ error: 'OpenAI API 키가 설정되지 않았습니다.' }, 400)
    }

    // PDF를 base64로 변환
    const arrayBuffer = await file.arrayBuffer()
    const base64 = btoa(String.fromCharCode(...new Uint8Array(arrayBuffer)))

    console.log(`📄 PDF 분석 시작: ${company} (${file.size} bytes)`)

    // OpenAI API로 PDF 분석
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          {
            role: 'user',
            content: [
              {
                type: 'text',
                text: `당신은 보험 약관 분석 전문가입니다. ${company}의 N대 수술비 특약 PDF 문서를 분석하여 다음 정보를 추출해주세요:

**목표**: ICD-10 진단코드 또는 수술명과 해당하는 N대 수술비 등급 매칭

**추출할 정보**:
1. ICD-10 진단코드 (예: H25.0, I21.0 등)
2. 진단명/수술명 (한글)
3. 해당하는 N대 수술비 등급 (예: 27대, 59대, 43대 등)
4. 1-5종 수술 분류 (해당되는 경우)

**JSON 형식으로 응답해주세요**:
\`\`\`json
{
  "company": "${company}",
  "total_n": "119대",
  "items": [
    {
      "code": "H25.0",
      "name": "노년성 초기백내장",
      "n_grade": "27대",
      "type_1to5": "3종"
    }
  ]
}
\`\`\`

**주의사항**:
- ICD-10 코드가 명시된 경우 반드시 포함
- N대 등급이 명확한 경우만 포함
- 최대한 많은 매칭 정보 추출 (최소 20개 이상 목표)
- 불확실한 정보는 제외`
              },
              {
                type: 'image_url',
                image_url: {
                  url: `data:application/pdf;base64,${base64}`
                }
              }
            ]
          }
        ],
        max_tokens: 4096,
        temperature: 0.3
      })
    })

    if (!response.ok) {
      const error = await response.text()
      console.error('OpenAI API 오류:', error)
      return c.json({ 
        error: 'OpenAI API 호출 실패', 
        details: error 
      }, 500)
    }

    const result = await response.json()
    const content = result.choices[0]?.message?.content

    if (!content) {
      return c.json({ error: 'GPT 응답이 비어있습니다' }, 500)
    }

    // JSON 추출
    let extracted = null
    const jsonMatch = content.match(/```json\n([\s\S]*?)\n```/) || 
                     content.match(/\{[\s\S]*\}/)
    
    if (jsonMatch) {
      const jsonStr = jsonMatch[1] || jsonMatch[0]
      extracted = JSON.parse(jsonStr)
    } else {
      return c.json({ 
        error: 'JSON 형식 응답을 추출할 수 없습니다',
        rawContent: content 
      }, 500)
    }

    console.log(`✅ PDF 분석 완료: ${extracted.items?.length || 0}개 항목 추출`)

    return c.json({
      success: true,
      data: extracted,
      itemCount: extracted.items?.length || 0
    })
  } catch (error) {
    console.error('PDF 분석 오류:', error)
    return c.json({ 
      error: 'PDF 분석 중 오류가 발생했습니다',
      details: error instanceof Error ? error.message : String(error)
    }, 500)
  }
})

// ==================== 하이브리드 검색 (DB + GPT) ====================

// 하이브리드 검색: DB 우선, GPT 보완
app.get('/api/gpt-search', async (c) => {
  const query = c.req.query('q')
  
  if (!query) {
    return c.json({ error: '검색어를 입력해주세요' }, 400)
  }

  try {
    const apiKey = c.env.OPENAI_API_KEY
    
    if (!apiKey) {
      return c.json({ 
        error: 'OpenAI API 키가 설정되지 않았습니다.' 
      }, 400)
    }

    console.log(`🔍 하이브리드 검색 시작: "${query}"`)
    const startTime = Date.now()
    
    // 하이브리드 검색 실행 (Perplexity API 포함)
    const perplexityApiKey = c.env.PERPLEXITY_API_KEY
    const result = await hybridSearch(query, c.env.DB, apiKey, perplexityApiKey)
    
    const searchTime = Date.now() - startTime
    console.log(`✅ 검색 완료: ${result.stats.totalResults}개 (DB: ${result.stats.fromDB}, GPT: ${result.stats.fromGPT}, ${searchTime}ms)`)

    return c.json({
      success: result.success,
      results: result.results,
      answer: result.summary,
      source: 'hybrid (database + gpt-3.5-turbo)',
      stats: result.stats,
      searchTime: new Date().toISOString(),
      error: result.error
    })
  } catch (error) {
    console.error('Hybrid search error:', error)
    return c.json({ 
      error: '검색 중 오류가 발생했습니다',
      details: error instanceof Error ? error.message : String(error)
    }, 500)
  }
})

// Cloudflare Workers Cron Job (매주 일요일 오전 2시 실행)
export default {
  ...app,
  async scheduled(event: ScheduledEvent, env: Bindings, ctx: ExecutionContext) {
    console.log('Running scheduled auto-update...')
    
    // 주요 보험사 URL 목록
    const insuranceCompanies = [
      { code: 'SAMSUNG', url: 'https://www.samsungfire.com' },
      { code: 'HYUNDAI', url: 'https://www.hi.co.kr' },
      { code: 'DB', url: 'https://www.idbins.com' },
      // 추가 보험사...
    ]
    
    for (const company of insuranceCompanies) {
      try {
        await runAutoUpdate(
          {
            DB: env.DB,
            OPENAI_API_KEY: env.OPENAI_API_KEY
          },
          company.url,
          company.code
        )
        
        // 각 회사 간 1초 대기 (Rate limiting)
        await new Promise(resolve => setTimeout(resolve, 1000))
      } catch (error) {
        console.error(`Failed to update ${company.code}:`, error)
      }
    }
    
    console.log('Scheduled auto-update completed')
  }
} as ExportedHandler<Bindings>
