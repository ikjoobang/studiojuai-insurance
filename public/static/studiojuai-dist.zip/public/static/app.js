// 전역 변수
let currentReport = null;
const ADMIN_PASSWORD = '01031593697as!@';
let surgeryDB = []; // EDI 수가코드 DB (구버전)
let diagnosisDB = []; // ICD 진단코드 DB (신규)

// 페이지 로드 시 초기화
document.addEventListener('DOMContentLoaded', () => {
  loadPopularSearches();
  initDarkMode();
  loadSurgeryDB(); // 구 DB 로드
  loadDiagnosisDB(); // 신규 ICD 진단코드 로드
});

// ==================== DB 로드 ====================

async function loadSurgeryDB() {
  try {
    const response = await fetch('/static/surgery-db.json');
    surgeryDB = await response.json();
    console.log(`✔️ ${surgeryDB.length}개 EDI 수가코드 데이터 로드 완료`);
  } catch (error) {
    console.error(' EDI DB 로드 실패:', error);
  }
}

async function loadDiagnosisDB() {
  try {
    const response = await fetch('/static/diagnosis-codes.json');
    diagnosisDB = await response.json();
    console.log(`✔️ ${diagnosisDB.length}개 ICD 진단코드 데이터 로드 완료`);
  } catch (error) {
    console.error(' ICD DB 로드 실패:', error);
  }
}

// ==================== DB 검색 ====================

async function searchFromDB() {
  const input = document.getElementById('dbSearchInput');
  const query = input.value.trim();
  
  if (!query) {
    alert('검색어를 입력하세요');
    return;
  }
  
  // ICD 진단코드 우선 검색
  const q = query.toLowerCase();
  const diagnosisResults = diagnosisDB.filter(item => {
    return item.code.toLowerCase().includes(q) || 
           item.name.toLowerCase().includes(q) ||
           (item.description && item.description.toLowerCase().includes(q));
  });
  
  // EDI 수가코드도 검색 (참고용)
  const surgeryResults = surgeryDB.filter(item => {
    return item.code.toLowerCase().includes(q) || 
           item.name.toLowerCase().includes(q);
  });
  
  // DB에 결과가 없으면 Perplexity 웹 검색
  if (diagnosisResults.length === 0 && surgeryResults.length === 0) {
    console.log('DB에 결과 없음, Perplexity 웹 검색 시작...');
    await searchWithGPT(); // Perplexity + GPT 검색 실행
    return;
  }
  
  displayDBResults(diagnosisResults, surgeryResults, query);
}

function showDBSuggestions(query) {
  const suggestionsDiv = document.getElementById('dbSuggestions');
  
  if (!query || query.length < 2) {
    suggestionsDiv.classList.add('hidden');
    return;
  }
  
  const q = query.toLowerCase();
  
  // ICD 진단코드 우선 검색 (최대 5개)
  const diagnosisSuggestions = diagnosisDB.filter(item => {
    return item.code.toLowerCase().includes(q) || 
           item.name.toLowerCase().includes(q) ||
           (item.description && item.description.toLowerCase().includes(q));
  }).slice(0, 5);
  
  if (diagnosisSuggestions.length === 0) {
    suggestionsDiv.classList.add('hidden');
    return;
  }
  
  suggestionsDiv.innerHTML = diagnosisSuggestions.map(item => `
    <div class="p-3 hover:bg-blue-50 cursor-pointer border-b last:border-b-0" 
         onclick="selectDBSuggestion('${item.code}', '${item.name}')">
      <div class="font-bold text-gray-900">${item.name}</div>
      <div class="text-sm text-gray-600">
        <span class="bg-blue-100 px-2 py-1 rounded text-blue-800 font-mono font-bold">${item.code}</span>
        <span class="ml-2 text-xs text-gray-500">ICD-10 진단코드</span>
        ${item.category ? `<span class="ml-2 text-gray-500">${item.category}</span>` : ''}
      </div>
    </div>
  `).join('');
  
  suggestionsDiv.classList.remove('hidden');
}

function selectDBSuggestion(code, name) {
  const input = document.getElementById('dbSearchInput');
  input.value = `${code} ${name}`;
  document.getElementById('dbSuggestions').classList.add('hidden');
  searchFromDB();
}

function displayDBResults(diagnosisResults, surgeryResults, query) {
  const resultsDiv = document.getElementById('dbSearchResults');
  
  if (diagnosisResults.length === 0 && surgeryResults.length === 0) {
    resultsDiv.innerHTML = `
      <div class="bg-yellow-50 border-l-4 border-yellow-400 p-6 rounded">
        <div class="flex items-start">
          <i class="fas fa-exclamation-triangle text-yellow-500 text-2xl mr-3"></i>
          <div>
            <h3 class="font-bold text-yellow-900 mb-2">검색 결과 없음</h3>
            <p class="text-yellow-800">"${query}"에 대한 진단코드 정보가 DB에 없습니다.</p>
            <p class="text-sm text-yellow-700 mt-2"> 아래 AI 검색을 사용해보세요 (실시간 웹 검색)</p>
          </div>
        </div>
      </div>
    `;
    resultsDiv.classList.remove('hidden');
    return;
  }
  
  let html = '';
  
  // ICD 진단코드 결과
  if (diagnosisResults.length > 0) {
    html += `
      <div class="bg-white rounded-lg shadow-lg border-2 border-blue-400 p-6 mb-6">
        <h3 class="text-xl font-bold text-gray-900 mb-4 flex items-center">
          <i class="fas fa-stethoscope text-blue-600 mr-2"></i>
          ICD-10 진단코드: ${diagnosisResults.length}개 ()
          <span class="ml-3 text-xs bg-blue-100 text-blue-800 px-3 py-1 rounded-full">병원 진단서 코드</span>
        </h3>
        <div class="space-y-4">
          ${diagnosisResults.map((item, index) => `
            <div class="border-l-4 border-blue-500 bg-blue-50 p-4 rounded">
              <div class="flex items-start gap-3">
                <span class="text-2xl font-bold text-blue-600">${['❶','❷','❸','❹','❺','❻','❼','❽','❾','❿'][index] || (index + 1)}</span>
                <div class="flex-1">
                  <h4 class="font-bold text-lg text-gray-900">${item.name}</h4>
                  <div class="mt-2 space-y-1">
                    <div class="text-sm">
                      <span class="font-semibold text-gray-700">■ 진단코드:</span>
                      <span class="bg-blue-200 px-3 py-1 rounded font-mono text-blue-900 ml-2 font-bold text-base">${item.code}</span>
                    </div>
                    ${item.chapter ? `
                      <div class="text-sm">
                        <span class="font-semibold text-gray-700">■ 대분류:</span>
                        <span class="ml-2 text-gray-600">${item.chapter}</span>
                      </div>
                    ` : ''}
                    ${item.section ? `
                      <div class="text-sm">
                        <span class="font-semibold text-gray-700">■ 중분류:</span>
                        <span class="ml-2 text-gray-600">${item.section}</span>
                      </div>
                    ` : ''}
                    ${item.category ? `
                      <div class="text-sm">
                        <span class="font-semibold text-gray-700">■ 질환군:</span>
                        <span class="ml-2 text-gray-600">${item.category}</span>
                      </div>
                    ` : ''}
                    ${item.description ? `
                      <div class="text-sm text-gray-600 mt-2 leading-relaxed bg-white p-3 rounded border border-blue-200">
                        <span class="font-semibold text-gray-700">✔️ 설명:</span> ${item.description}
                      </div>
                    ` : ''}
                  </div>
                </div>
              </div>
            </div>
          `).join('')}
        </div>
        
        <div class="mt-6 p-4 bg-blue-50 rounded border-l-4 border-blue-500">
          <p class="text-sm text-blue-900">
            <i class="fas fa-hospital text-blue-600 mr-2"></i>
            <strong>ICD-10 진단코드:</strong> 실제 병원 진단서, 처방전, 입원 기록에 표기되는 질병분류코드입니다.
            보험 청구 시 진단서에서 이 코드를 확인하세요.
          </p>
        </div>
      </div>
    `;
  }
  
  // EDI 수가코드 결과 (참고용)
  if (surgeryResults.length > 0) {
    html += `
      <div class="bg-white rounded-lg shadow-lg border-2 border-green-300 p-6">
        <h3 class="text-xl font-bold text-gray-900 mb-4 flex items-center">
          <i class="fas fa-procedures text-green-600 mr-2"></i>
          EDI 수가코드: ${surgeryResults.length}개 ()
          <span class="ml-3 text-xs bg-green-100 text-green-800 px-3 py-1 rounded-full">수술/시술/검사 코드</span>
        </h3>
        <div class="space-y-4">
          ${surgeryResults.map((item, index) => `
            <div class="border-l-4 border-green-500 bg-green-50 p-4 rounded">
              <div class="flex items-start gap-3">
                <span class="text-2xl font-bold text-green-600">${['❶','❷','❸','❹','❺','❻','❼','❽','❾','❿'][index] || (index + 1)}</span>
                <div class="flex-1">
                  <h4 class="font-bold text-lg text-gray-900">${item.name}</h4>
                  <div class="mt-2 space-y-1">
                    <div class="text-sm">
                      <span class="font-semibold text-gray-700">■ 수가코드:</span>
                      <span class="bg-green-100 px-2 py-1 rounded font-mono text-green-800 ml-2">${item.code}</span>
                    </div>
                    ${item.category ? `
                      <div class="text-sm">
                        <span class="font-semibold text-gray-700">■ 분류:</span>
                        <span class="ml-2 text-gray-600">${item.category}</span>
                      </div>
                    ` : ''}
                    ${item.description ? `
                      <div class="text-sm text-gray-600 mt-2 leading-relaxed">
                        ${item.description}
                      </div>
                    ` : ''}
                  </div>
                </div>
              </div>
            </div>
          `).join('')}
        </div>
        
        <div class="mt-6 p-4 bg-green-50 rounded border-l-4 border-green-500">
          <p class="text-sm text-green-900">
            <i class="fas fa-info-circle mr-2"></i>
            <strong>EDI 수가코드:</strong> 의료행위(수술, 시술, 검사)에 대한 건강보험 청구용 코드입니다.
            진단코드와 다른 체계이니 참고용으로만 활용하세요.
          </p>
        </div>
      </div>
    `;
  }
  
  resultsDiv.innerHTML = html;
  resultsDiv.classList.remove('hidden');
}

// ==================== 다크모드 ====================

function initDarkMode() {
  // 로컬 스토리지에서 다크모드 설정 불러오기
  const isDark = localStorage.getItem('darkMode') === 'true';
  if (isDark) {
    document.body.classList.add('dark-mode');
    updateDarkModeIcon(true);
  }
}

function toggleDarkMode() {
  const isDark = document.body.classList.toggle('dark-mode');
  localStorage.setItem('darkMode', isDark);
  updateDarkModeIcon(isDark);
}

function updateDarkModeIcon(isDark) {
  const icon = document.getElementById('darkModeIcon');
  if (icon) {
    icon.textContent = isDark ? '☀️' : '🌙';
  }
}

// ==================== 관리자 인증 ====================

function showAdminPanel() {
  const password = prompt('관리자 비밀번호를 입력하세요:');
  
  if (password !== ADMIN_PASSWORD) {
    alert(' 비밀번호가 틀렸습니다.');
    return;
  }
  
  // 비밀번호 확인 후 관리자 패널 표시
  document.getElementById('adminModal').classList.remove('hidden');
}

// 검색 입력 핸들러
function handleSearch(event) {
  if (event.key === 'Enter') {
    performSearch();
  } else {
    const query = event.target.value.trim();
    if (query.length >= 2) {
      searchSurgeries(query);
    } else {
      document.getElementById('searchResults').classList.add('hidden');
    }
  }
}

// 수술 검색 (자동완성)
async function searchSurgeries(query) {
  try {
    const response = await fetch(`/api/search/surgery?q=${encodeURIComponent(query)}`);
    const data = await response.json();
    
    if (data.surgeries && data.surgeries.length > 0) {
      displaySearchResults(data.surgeries);
    } else {
      document.getElementById('searchResults').innerHTML = `
        <div class="text-gray-500 text-sm">검색 결과가 없습니다</div>
      `;
      document.getElementById('searchResults').classList.remove('hidden');
    }
  } catch (error) {
    console.error('Search error:', error);
  }
}

// 검색 결과 표시
function displaySearchResults(surgeries) {
  const resultsDiv = document.getElementById('searchResults');
  
  resultsDiv.innerHTML = `
    <div class="border border-gray-200 rounded-lg max-h-64 overflow-y-auto">
      ${surgeries.map(surgery => `
        <div 
          class="p-3 hover:bg-gray-50 cursor-pointer border-b last:border-b-0"
          onclick="selectSurgery(${surgery.id})"
        >
          <div class="font-medium text-gray-900">${surgery.name}</div>
          <div class="text-sm text-gray-500 mt-1">
            ${surgery.edi_code ? `EDI: ${surgery.edi_code}` : ''} 
            ${surgery.kcd_code ? `| KCD: ${surgery.kcd_code}` : ''}
            ${surgery.medical_classification ? `| ${surgery.medical_classification}` : ''}
            ${surgery.difficulty_level ? `| ${surgery.difficulty_level}종 수술` : ''}
          </div>
        </div>
      `).join('')}
    </div>
  `;
  
  resultsDiv.classList.remove('hidden');
}

// 수술 선택
function selectSurgery(surgeryId) {
  document.getElementById('searchResults').classList.add('hidden');
  loadAnalysisReport(surgeryId);
}

// 검색 버튼 클릭
async function performSearch() {
  const query = document.getElementById('searchInput').value.trim();
  
  if (!query) {
    alert('검색어를 입력해주세요');
    return;
  }
  
  try {
    const response = await fetch(`/api/search/surgery?q=${encodeURIComponent(query)}`);
    const data = await response.json();
    
    if (data.surgeries && data.surgeries.length > 0) {
      // 첫 번째 결과 자동 선택
      selectSurgery(data.surgeries[0].id);
    } else {
      alert('검색 결과가 없습니다. 관리자에게 수술 정보 추가를 요청해주세요.');
    }
  } catch (error) {
    console.error('Search error:', error);
    alert('검색 중 오류가 발생했습니다');
  }
}

// 분석 리포트 로드
async function loadAnalysisReport(surgeryId) {
  try {
    // 로딩 표시
    document.getElementById('analysisResult').classList.remove('hidden');
    document.getElementById('surgeryInfo').innerHTML = '<div class="text-center py-8"><i class="fas fa-spinner fa-spin text-3xl text-blue-600"></i><div class="mt-2 text-gray-600">분석 중...</div></div>';
    
    const response = await fetch(`/api/surgery/${surgeryId}/report`);
    const data = await response.json();
    
    if (data.error) {
      alert(data.error);
      return;
    }
    
    currentReport = data;
    displayReport(data);
  } catch (error) {
    console.error('Report error:', error);
    alert('리포트 생성 중 오류가 발생했습니다');
  }
}

// 리포트 표시
function displayReport(data) {
  const { surgery, typeBenefits, nBenefits, risk } = data;
  
  // 수술 기본 정보
  document.getElementById('surgeryInfo').innerHTML = `
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div>
        <div class="text-sm text-gray-600 mb-1">수술명</div>
        <div class="font-semibold text-lg">${surgery.name}</div>
        ${surgery.name_en ? `<div class="text-sm text-gray-500">${surgery.name_en}</div>` : ''}
      </div>
      <div>
        <div class="text-sm text-gray-600 mb-1">수술코드</div>
        <div class="font-semibold">${surgery.edi_code || '-'} ${surgery.kcd_code ? `(KCD: ${surgery.kcd_code})` : ''}</div>
      </div>
      <div>
        <div class="text-sm text-gray-600 mb-1">의학적 분류</div>
        <div class="font-semibold">${surgery.medical_classification || '-'}</div>
      </div>
      <div>
        <div class="text-sm text-gray-600 mb-1">난이도</div>
        <div class="font-semibold">${surgery.difficulty_level ? surgery.difficulty_level + '종 수술' : '-'}</div>
      </div>
      ${surgery.description ? `
      <div class="md:col-span-2">
        <div class="text-sm text-gray-600 mb-1">설명</div>
        <div class="text-gray-700">${surgery.description}</div>
      </div>
      ` : ''}
    </div>
  `;
  
  // 1-5종 수술비 특약
  if (typeBenefits && typeBenefits.length > 0) {
    document.getElementById('typeBenefits').innerHTML = `
      <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
          <thead class="bg-gray-50">
            <tr>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">보험사명</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">특약명</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">해당종류</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">보장금액</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">보장조건</th>
            </tr>
          </thead>
          <tbody class="bg-white divide-y divide-gray-200">
            ${typeBenefits.map(benefit => `
              <tr>
                <td class="px-6 py-4 whitespace-nowrap font-medium text-gray-900">${benefit.company_name}</td>
                <td class="px-6 py-4 whitespace-nowrap text-gray-700">${benefit.benefit_name}</td>
                <td class="px-6 py-4 whitespace-nowrap">
                  <span class="px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                    ${benefit.surgery_type}종 수술
                  </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-gray-700">
                  ${benefit.benefit_amount ? formatCurrency(benefit.benefit_amount) : '-'}
                </td>
                <td class="px-6 py-4 text-gray-700">${benefit.benefit_conditions || '-'}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  } else {
    document.getElementById('typeBenefits').innerHTML = `
      <div class="text-center py-8 text-gray-500">
        <i class="fas fa-inbox text-4xl mb-2"></i>
        <div>등록된 1-5종 특약 정보가 없습니다</div>
        <div class="text-sm mt-1">관리자에게 데이터 추가를 요청해주세요</div>
      </div>
    `;
  }
  
  // N대 수술비 특약
  if (nBenefits && nBenefits.length > 0) {
    document.getElementById('nBenefits').innerHTML = `
      <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
          <thead class="bg-gray-50">
            <tr>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">보험사명</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">N대특약명</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">전체구성</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">보장여부</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">세부등급</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">보장금액</th>
            </tr>
          </thead>
          <tbody class="bg-white divide-y divide-gray-200">
            ${nBenefits.map(benefit => `
              <tr>
                <td class="px-6 py-4 whitespace-nowrap font-medium text-gray-900">${benefit.company_name}</td>
                <td class="px-6 py-4 whitespace-nowrap text-gray-700">${benefit.total_n}대수술비</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">${benefit.benefit_structure}</td>
                <td class="px-6 py-4 whitespace-nowrap">
                  ${benefit.is_covered ? 
                    '<span class="px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">보장</span>' : 
                    '<span class="px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">미보장</span>'
                  }
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                  ${benefit.sub_category ? 
                    `<span class="px-2 py-1 text-xs font-semibold rounded-full bg-purple-100 text-purple-800">${benefit.sub_category}</span>` : 
                    '-'
                  }
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-gray-700">
                  ${benefit.benefit_amount ? formatCurrency(benefit.benefit_amount) : '-'}
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  } else {
    document.getElementById('nBenefits').innerHTML = `
      <div class="text-center py-8 text-gray-500">
        <i class="fas fa-inbox text-4xl mb-2"></i>
        <div>등록된 N대 특약 정보가 없습니다</div>
        <div class="text-sm mt-1">관리자에게 데이터 추가를 요청해주세요</div>
      </div>
    `;
  }
  
  // 리스크 정보
  if (risk) {
    document.getElementById('riskInfo').innerHTML = `
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <div class="flex items-center mb-2">
            <i class="fas fa-redo text-orange-500 mr-2"></i>
            <span class="font-semibold text-gray-900">재발 가능성</span>
          </div>
          <div class="text-gray-700">${risk.recurrence_risk || '정보 없음'}</div>
          ${risk.recurrence_description ? `<div class="text-sm text-gray-600 mt-1">${risk.recurrence_description}</div>` : ''}
        </div>
        
        <div>
          <div class="flex items-center mb-2">
            <i class="fas fa-procedures text-red-500 mr-2"></i>
            <span class="font-semibold text-gray-900">재수술 필요성</span>
          </div>
          <div class="text-gray-700">${risk.reoperation_risk || '정보 없음'}</div>
        </div>
        
        <div>
          <div class="flex items-center mb-2">
            <i class="fas fa-heartbeat text-purple-500 mr-2"></i>
            <span class="font-semibold text-gray-900">합병증 위험</span>
          </div>
          <div class="text-gray-700">${risk.complication_risk || '정보 없음'}</div>
        </div>
        
        <div>
          <div class="flex items-center mb-2">
            <i class="fas fa-plus-circle text-blue-500 mr-2"></i>
            <span class="font-semibold text-gray-900">추가 치료 가능성</span>
          </div>
          <div class="text-gray-700">${risk.additional_treatment || '정보 없음'}</div>
        </div>
        
        ${risk.insurance_notes ? `
        <div class="md:col-span-2">
          <div class="flex items-center mb-2">
            <i class="fas fa-exclamation-circle text-yellow-500 mr-2"></i>
            <span class="font-semibold text-gray-900">보험 청구 시 주의사항</span>
          </div>
          <div class="text-gray-700 bg-yellow-50 p-3 rounded">${risk.insurance_notes}</div>
        </div>
        ` : ''}
      </div>
    `;
  } else {
    document.getElementById('riskInfo').innerHTML = `
      <div class="text-center py-8 text-gray-500">
        <i class="fas fa-inbox text-4xl mb-2"></i>
        <div>등록된 리스크 정보가 없습니다</div>
      </div>
    `;
  }
  
  // 고객 상담 포인트
  displayConsultingPoints(typeBenefits, nBenefits);
}

// 고객 상담 포인트 생성
function displayConsultingPoints(typeBenefits, nBenefits) {
  let html = '<div class="space-y-4">';
  
  // 최고/최저 보장 분석
  if (typeBenefits && typeBenefits.length > 0) {
    const withAmount = typeBenefits.filter(b => b.benefit_amount);
    if (withAmount.length > 0) {
      const maxBenefit = withAmount.reduce((prev, curr) => 
        prev.benefit_amount > curr.benefit_amount ? prev : curr
      );
      const minBenefit = withAmount.reduce((prev, curr) => 
        prev.benefit_amount < curr.benefit_amount ? prev : curr
      );
      
      html += `
        <div class="bg-green-50 p-4 rounded-lg">
          <div class="font-semibold text-green-900 mb-2">
            <i class="fas fa-trophy mr-2"></i>최고 보장
          </div>
          <div class="text-green-800">
            ${maxBenefit.company_name} - ${formatCurrency(maxBenefit.benefit_amount)} 
            (${maxBenefit.surgery_type}종 수술)
          </div>
        </div>
        
        <div class="bg-blue-50 p-4 rounded-lg">
          <div class="font-semibold text-blue-900 mb-2">
            <i class="fas fa-info-circle mr-2"></i>최저 보장
          </div>
          <div class="text-blue-800">
            ${minBenefit.company_name} - ${formatCurrency(minBenefit.benefit_amount)} 
            (${minBenefit.surgery_type}종 수술)
          </div>
        </div>
      `;
    }
  }
  
  // N대 특약 보장 현황
  if (nBenefits && nBenefits.length > 0) {
    const covered = nBenefits.filter(b => b.is_covered);
    if (covered.length > 0) {
      html += `
        <div class="bg-purple-50 p-4 rounded-lg">
          <div class="font-semibold text-purple-900 mb-2">
            <i class="fas fa-check-circle mr-2"></i>N대 특약 보장 (${covered.length}개 보험사)
          </div>
          <div class="text-purple-800 space-y-1">
            ${covered.map(b => `
              <div>• ${b.company_name} ${b.total_n}대 특약 - ${b.sub_category || '기본'} 
              ${b.benefit_amount ? '(' + formatCurrency(b.benefit_amount) + ')' : ''}</div>
            `).join('')}
          </div>
        </div>
      `;
    }
  }
  
  html += `
    <div class="bg-yellow-50 p-4 rounded-lg">
      <div class="font-semibold text-yellow-900 mb-2">
        <i class="fas fa-exclamation-triangle mr-2"></i>주의사항
      </div>
      <ul class="text-yellow-800 space-y-1 text-sm">
        <li>• 약관은 보험사별로 변경될 수 있으니 계약 전 반드시 최신 약관을 확인하세요</li>
        <li>• 면책기간 및 감액기간을 반드시 확인하세요</li>
        <li>• 고객의 나이, 건강 상태, 기존 보험 가입 여부에 따라 맞춤 상담이 필요합니다</li>
      </ul>
    </div>
  `;
  
  html += '</div>';
  document.getElementById('consultingPoints').innerHTML = html;
}

// 인기 검색어 로드
async function loadPopularSearches() {
  try {
    const response = await fetch('/api/popular-searches');
    const data = await response.json();
    
    if (data.searches && data.searches.length > 0) {
      document.getElementById('popularSearches').innerHTML = data.searches.map(search => `
        <button 
          onclick="document.getElementById('searchInput').value='${search.surgery_name}'; performSearch();"
          class="px-3 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 text-sm transition-colors"
        >
          ${search.surgery_name}
          <span class="ml-2 text-xs text-gray-500">(${search.search_count}회)</span>
        </button>
      `).join('');
    } else {
      document.getElementById('popularSearches').innerHTML = `
        <div class="text-gray-500 text-sm">아직 검색 기록이 없습니다</div>
      `;
    }
  } catch (error) {
    console.error('Popular searches error:', error);
  }
}

// 금액 포맷팅
function formatCurrency(amount) {
  return new Intl.NumberFormat('ko-KR', {
    style: 'currency',
    currency: 'KRW'
  }).format(amount);
}

// 리포트 다운로드
function downloadReport() {
  if (!currentReport) {
    alert('리포트 데이터가 없습니다');
    return;
  }
  
  const { surgery, typeBenefits, nBenefits, risk } = currentReport;
  
  let text = `
========================================
보험 수술비 특약 분석 리포트
========================================
분석일: ${new Date().toLocaleString('ko-KR')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📋 수술 기본 정보
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
수술명: ${surgery.name}
영문명: ${surgery.name_en || '-'}
수술코드: ${surgery.edi_code || '-'}
KCD코드: ${surgery.kcd_code || '-'}
의학적 분류: ${surgery.medical_classification || '-'}
난이도: ${surgery.difficulty_level ? surgery.difficulty_level + '종 수술' : '-'}
설명: ${surgery.description || '-'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 1-5종 수술비 특약 보장 현황
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`;

  if (typeBenefits && typeBenefits.length > 0) {
    typeBenefits.forEach(benefit => {
      text += `
보험사: ${benefit.company_name}
특약명: ${benefit.benefit_name}
해당종류: ${benefit.surgery_type}종 수술
보장금액: ${benefit.benefit_amount ? formatCurrency(benefit.benefit_amount) : '-'}
보장조건: ${benefit.benefit_conditions || '-'}
---
`;
    });
  } else {
    text += '등록된 정보가 없습니다.\n';
  }

  text += `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 N대 수술비 특약 세부등급 보장 현황
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`;

  if (nBenefits && nBenefits.length > 0) {
    nBenefits.forEach(benefit => {
      text += `
보험사: ${benefit.company_name}
N대특약: ${benefit.total_n}대수술비
전체구성: ${benefit.benefit_structure}
보장여부: ${benefit.is_covered ? '보장' : '미보장'}
세부등급: ${benefit.sub_category || '-'}
보장금액: ${benefit.benefit_amount ? formatCurrency(benefit.benefit_amount) : '-'}
---
`;
    });
  } else {
    text += '등록된 정보가 없습니다.\n';
  }

  if (risk) {
    text += `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚠️ 가능성 정보 (리스크 대비)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
재발 가능성: ${risk.recurrence_risk || '정보 없음'}
${risk.recurrence_description ? '상세: ' + risk.recurrence_description : ''}

재수술 필요성: ${risk.reoperation_risk || '정보 없음'}
합병증 위험: ${risk.complication_risk || '정보 없음'}
추가 치료 가능성: ${risk.additional_treatment || '정보 없음'}
${risk.insurance_notes ? '\n보험 청구 주의사항: ' + risk.insurance_notes : ''}
`;
  }

  text += `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 중요 유의사항
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• 약관은 보험사별로 변경될 수 있으니 계약 전 반드시 최신 약관을 확인하세요
• 면책기간 및 감액기간을 반드시 확인하세요
• 고객의 나이, 건강 상태, 기존 보험 가입 여부에 따라 맞춤 상담이 필요합니다
• 본 리포트는 참고용이며, 정확한 보장 내용은 약관을 확인해주세요

========================================
`;

  // 다운로드
  const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `보험수술비특약분석_${surgery.name}_${new Date().toISOString().split('T')[0]}.txt`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  window.URL.revokeObjectURL(url);
}

// 관리자 패널 표시 (이미 위에 정의됨 - 중복 제거)

// 관리자 패널 닫기
function closeAdminPanel() {
  const modal = document.getElementById('adminModal');
  if (modal) {
    modal.classList.add('hidden');
  }
}

// 수술 추가 폼
function showAddSurgery() {
  alert('수술 정보 추가 기능은 개발 중입니다.\n\n현재는 데이터베이스에 직접 INSERT 쿼리로 추가해주세요.\n\nAPI: POST /api/admin/surgery');
}

// 보험 특약 추가 폼
function showAddBenefit() {
  alert('보험 특약 추가 기능은 개발 중입니다.\n\n현재는 데이터베이스에 직접 INSERT 쿼리로 추가해주세요.\n\nAPI: \n- POST /api/admin/type-benefit (1-5종 특약)\n- POST /api/admin/n-benefit-detail (N대 특약)');
}

// 통계 보기
function viewStats() {
  alert('통계 보기 기능은 개발 중입니다.');
}

// 자동 업데이트 트리거
async function triggerAutoUpdate() {
  const companyUrl = prompt('보험사 홈페이지 URL을 입력하세요:\n(예: https://www.samsungfire.com)');
  
  if (!companyUrl) return;
  
  const companyCode = prompt('보험사 코드를 입력하세요:\n(예: SAMSUNG, HYUNDAI, DB, KB, NH, HANWHA, MERITZ, DONGBU, LOTTE, HEUNGKUK, MG)');
  
  if (!companyCode) return;
  
  // 로딩 표시
  const loadingDiv = document.createElement('div');
  loadingDiv.id = 'loading-overlay';
  loadingDiv.className = 'fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center';
  loadingDiv.innerHTML = `
    <div class="bg-white rounded-lg p-8 max-w-md">
      <div class="text-center">
        <i class="fas fa-spinner fa-spin text-4xl text-blue-600 mb-4"></i>
        <h3 class="text-xl font-bold mb-2">자동 업데이트 진행 중...</h3>
        <p class="text-gray-600">OpenAI API로 약관을 분석하고 있습니다.</p>
        <p class="text-sm text-gray-500 mt-2">최대 1-2분 소요될 수 있습니다.</p>
      </div>
    </div>
  `;
  document.body.appendChild(loadingDiv);
  
  try {
    const response = await fetch('/api/admin/auto-update', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        company_url: companyUrl,
        company_code: companyCode
      })
    });
    
    const result = await response.json();
    
    // 로딩 제거
    document.body.removeChild(loadingDiv);
    
    if (result.success) {
      alert(`✔️ 자동 업데이트 성공!\n\n추가된 수술: ${result.surgeries_added}개\n추가된 특약: ${result.benefits_added}개\n\n페이지를 새로고침하여 업데이트된 데이터를 확인하세요.`);
      location.reload();
    } else {
      alert(` 자동 업데이트 실패\n\n오류: ${result.error}\n\n다시 시도해주세요.`);
    }
  } catch (error) {
    // 로딩 제거
    if (document.getElementById('loading-overlay')) {
      document.body.removeChild(loadingDiv);
    }
    
    console.error('Auto-update error:', error);
    alert(' 자동 업데이트 중 오류가 발생했습니다.\n\n' + error.message);
  }
}

// ==================== HIRA API 동기화 ====================

/**
 * HIRA 공공데이터 API에서 수술 코드 동기화
 */
async function syncHIRAData() {
  if (!confirm('⚠️ HIRA API 동기화를 시작하시겠습니까?\n\n수천 개의 수술 코드를 가져와 데이터베이스에 저장합니다.\n(시간이 다소 소요될 수 있습니다)')) {
    return;
  }

  // 로딩 오버레이 표시
  const loadingDiv = document.createElement('div');
  loadingDiv.id = 'loading-overlay';
  loadingDiv.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
  loadingDiv.innerHTML = `
    <div class="bg-white rounded-lg p-8 max-w-md text-center">
      <div class="animate-spin rounded-full h-16 w-16 border-b-2 border-primary mx-auto mb-4"></div>
      <div class="text-xl font-bold mb-2">HIRA API 동기화 중...</div>
      <div class="text-gray-600">건강보험심사평가원에서 수술 코드를 가져오고 있습니다.</div>
      <div class="text-sm text-gray-500 mt-2">잠시만 기다려주세요.</div>
    </div>
  `;
  document.body.appendChild(loadingDiv);

  try {
    const response = await fetch('/api/admin/hira-sync', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      }
    });

    const result = await response.json();

    // 로딩 제거
    if (document.getElementById('loading-overlay')) {
      document.body.removeChild(loadingDiv);
    }

    if (result.success) {
      alert(`✔️ HIRA API 동기화 완료!\n\n총 ${result.total.toLocaleString()}개의 수술 코드를 가져왔습니다.\n신규 저장: ${result.saved.toLocaleString()}개`);
      
      // 통계 업데이트
      if (typeof loadUpdateStats === 'function') {
        loadUpdateStats();
      }
    } else {
      alert(` HIRA API 동기화 실패\n\n오류: ${result.error}\n\n${result.details || ''}`);
    }
  } catch (error) {
    // 로딩 제거
    if (document.getElementById('loading-overlay')) {
      document.body.removeChild(loadingDiv);
    }
    
    console.error('HIRA sync error:', error);
    alert(' HIRA API 동기화 중 오류가 발생했습니다.\n\n' + error.message);
  }
}

/**
 * HIRA API에서 수술 검색 (실시간)
 */
async function searchHIRAAPI() {
  const query = prompt('HIRA API에서 검색할 수술명을 입력하세요:');
  
  if (!query || query.trim() === '') {
    return;
  }

  // 로딩 표시
  const loadingDiv = document.createElement('div');
  loadingDiv.id = 'hira-search-loading';
  loadingDiv.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
  loadingDiv.innerHTML = `
    <div class="bg-white rounded-lg p-8 max-w-md text-center">
      <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
      <div class="text-lg font-bold">HIRA API 검색 중...</div>
    </div>
  `;
  document.body.appendChild(loadingDiv);

  try {
    const response = await fetch(`/api/admin/hira-search?q=${encodeURIComponent(query)}`);
    const result = await response.json();

    // 로딩 제거
    document.body.removeChild(loadingDiv);

    if (result.success && result.results) {
      // 결과를 표시할 모달 생성
      const modalDiv = document.createElement('div');
      modalDiv.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4';
      modalDiv.innerHTML = `
        <div class="bg-white rounded-lg max-w-4xl w-full max-h-[80vh] overflow-hidden flex flex-col">
          <div class="p-6 border-b">
            <h3 class="text-2xl font-bold">HIRA API 검색 결과</h3>
            <p class="text-gray-600 mt-1">총 ${result.count}개의 결과를 찾았습니다</p>
          </div>
          <div class="overflow-y-auto flex-1 p-6">
            <div class="space-y-4">
              ${result.results.map(item => `
                <div class="border rounded-lg p-4 hover:bg-gray-50">
                  <div class="flex justify-between items-start">
                    <div>
                      <div class="font-bold text-lg">${item.의료수가코드명}</div>
                      <div class="text-sm text-gray-600 mt-1">
                        <span class="font-semibold">코드:</span> ${item.의료수가코드} | 
                        <span class="font-semibold">분류:</span> ${item.의료수가분류번호}
                      </div>
                      <div class="text-sm text-gray-600 mt-1">
                        <span class="font-semibold">급여구분:</span> ${item.급여구분} | 
                        <span class="font-semibold">상대가치점수:</span> ${item.상대가치점수}
                      </div>
                    </div>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
          <div class="p-6 border-t">
            <button onclick="this.closest('.fixed').remove()" class="w-full bg-gray-500 text-white px-6 py-2 rounded-lg hover:bg-gray-600">
              닫기
            </button>
          </div>
        </div>
      `;
      document.body.appendChild(modalDiv);

      // 모달 외부 클릭 시 닫기
      modalDiv.addEventListener('click', (e) => {
        if (e.target === modalDiv) {
          modalDiv.remove();
        }
      });
    } else {
      alert(`검색 결과가 없습니다.\n\n"${query}"에 대한 수술 코드를 찾을 수 없습니다.`);
    }
  } catch (error) {
    if (document.getElementById('hira-search-loading')) {
      document.body.removeChild(loadingDiv);
    }
    
    console.error('HIRA search error:', error);
    alert(' HIRA API 검색 중 오류가 발생했습니다.\n\n' + error.message);
  }
}

// ==================== GPT-3.5 기반 검색 ====================

/**
 * GPT-3.5로 수술 검색 (자연어 처리)
 */
async function searchWithGPT() {
  const searchInput = document.getElementById('searchInput');
  const query = searchInput?.value?.trim() || prompt('검색어를 입력하세요:\n\n예) 녹내장 수술, 백내장 관련 수술');
  
  if (!query || query === '') {
    return;
  }

  // 로딩 오버레이 표시
  const loadingDiv = document.createElement('div');
  loadingDiv.id = 'gpt-search-loading';
  loadingDiv.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
  loadingDiv.innerHTML = `
    <div class="bg-white dark:bg-gray-900 rounded-lg p-8 max-w-md text-center">
      <div class="animate-spin rounded-full h-16 w-16 border-b-2 border-orange-600 mx-auto mb-4"></div>
      <div class="text-xl font-bold mb-3 text-gray-900 dark:text-white"> Studioju_AI 검색중...</div>
      <div id="search-stage" class="space-y-3 mb-4">
        <div class="text-gray-700 dark:text-gray-300 font-semibold">
          <i class="fas fa-robot fa-spin mr-2 text-orange-500"></i>
          AI가 실시간 웹 검색 중...
        </div>
        <div class="text-gray-500 dark:text-gray-400 text-sm leading-relaxed">
          "${query}"에 대한 보험사별 정보를<br/>
          실시간으로 수집하고 있습니다
        </div>
      </div>
      <div class="text-xs text-gray-500 dark:text-gray-400 mt-4 p-3 bg-yellow-50 dark:bg-yellow-900 rounded border-l-4 border-yellow-400">
        <i class="fas fa-exclamation-triangle mr-1 text-yellow-600"></i>
        <strong>안내:</strong> 현재 D1 데이터베이스가 없어 모든 검색이 AI 웹 검색으로 처리됩니다.<br/>
        <span class="text-xs">정확도: 70-85% | 할루시네이션 가능성 있음</span>
      </div>
    </div>
  `;
  document.body.appendChild(loadingDiv);
  
  // 단계별 메시지 업데이트 함수
  const updateSearchStage = (stage, message, submessage = '') => {
    const stageDiv = document.getElementById('search-stage');
    if (stageDiv) {
      stageDiv.innerHTML = `
        <div class="text-gray-700 dark:text-gray-300 font-semibold">
          <i class="fas fa-cog fa-spin mr-2 text-${stage === 3 ? 'orange' : 'blue'}-500"></i>
          ${message}
        </div>
        ${submessage ? `
          <div class="text-gray-500 dark:text-gray-400 text-sm">
            ${submessage}
          </div>
        ` : ''}
      `;
    }
  };
  
  // 실제 검색 시작 - 더 이상 시뮬레이션 안 함
  // 백엔드가 처리 중이므로 메시지만 표시

  try {
    const response = await fetch(`/api/gpt-search?q=${encodeURIComponent(query)}`);
    const result = await response.json();

    // 로딩 제거
    document.body.removeChild(loadingDiv);

    if (result.success) {
      // 검색 통계 표시
      const statsHTML = result.stats ? `
        <div class="mb-4 p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-blue-200">
          <div class="flex items-center justify-between flex-wrap gap-2">
            <div class="flex items-center gap-3">
              <i class="fas fa-chart-bar text-blue-600 text-xl"></i>
              <span class="font-bold text-gray-900">검색 통계</span>
            </div>
            <div class="flex gap-4 text-sm">
              <span class="px-3 py-1 bg-green-100 text-green-800 rounded-full font-semibold">
                <i class="fas fa-database mr-1"></i>
                DB: ${result.stats.fromDB}개
              </span>
              <span class="px-3 py-1 bg-orange-100 text-orange-800 rounded-full font-semibold">
                <i class="fas fa-robot mr-1"></i>
                AI: ${result.stats.fromGPT}개
              </span>
              <span class="px-3 py-1 bg-gray-100 text-gray-800 rounded-full font-semibold">
                <i class="fas fa-bolt mr-1"></i>
                ${result.stats.searchTime}ms
              </span>
            </div>
          </div>
        </div>
      ` : '';
      
      // 결과 HTML 생성
      let resultsHTML = statsHTML;
      
      if (result.results && result.results.length > 0) {
        resultsHTML = result.results.map((item, index) => {
          // Circle emoji 사용 (❶❷❸❹❺❻)
          const circleNum = ['❶', '❷', '❸', '❹', '❺', '❻'][index] || `⓪${index + 1}`;
          
          let content = `
            <div class="border rounded-lg mb-8 bg-white dark:bg-gray-800 shadow-sm
                        px-4 md:px-10 lg:px-12 py-6 md:py-8
                        text-base md:text-[15px] lg:text-[16px]
                        leading-relaxed md:leading-[1.5] lg:leading-[1.6]
                        tracking-tight md:tracking-[-0.01em]
                        max-w-full md:max-w-[680px] lg:max-w-[720px] mx-auto
                        dark:text-gray-100 dark:border-gray-700">
              <!-- 수술 기본 정보 -->
              <div class="border-b dark:border-gray-700 pb-6 mb-6">
                <div class="flex items-center gap-3 mb-4">
                  <span class="text-4xl font-bold text-orange-600">${circleNum}</span>
                  <div class="flex-1">
                    <div class="font-bold text-2xl md:text-3xl text-gray-900 mb-2">${item.name || '수술명 없음'}</div>
                    <div class="text-sm md:text-base text-gray-600 mt-2">
                      <span class="font-semibold">■ 코드:</span> 
                      <span class="bg-orange-100 px-3 py-1 rounded font-mono text-orange-700">${item.code || 'N/A'}</span>
                    </div>
                  </div>
                </div>
                ${item.description ? `
                  <div class="text-sm md:text-base text-gray-700 dark:text-gray-300 bg-blue-50 dark:bg-blue-900 p-4 rounded mt-4 leading-relaxed">
                    <i class="fas fa-info-circle text-blue-500 dark:text-blue-300 mr-2"></i>
                    <strong>■ 설명:</strong><br/>
                    <span class="ml-6">${item.description}</span>
                  </div>
                ` : ''}
                
                <!-- 데이터 출처 배지 -->
                <div class="flex items-center gap-2 mt-4 flex-wrap">
                  ${item.dataSource === 'database' ? `
                    <span class="inline-flex items-center px-4 py-2 rounded-full text-sm font-bold bg-green-500 text-white border-2 border-green-600 shadow-lg">
                      <i class="fas fa-database mr-2"></i>
                      데이터베이스 ()
                    </span>
                  ` : item.dataSource === 'gpt' ? `
                    <span class="inline-flex items-center px-4 py-2 rounded-full text-sm font-bold bg-orange-500 text-white border-2 border-orange-600 shadow-lg animate-pulse">
                      <i class="fas fa-robot mr-2"></i>
                      AI 검색 ()
                    </span>
                    <span class="inline-flex items-center px-3 py-1 rounded text-xs bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200">
                      <i class="fas fa-exclamation-triangle mr-1"></i>
                      할루시네이션 가능성 있음
                    </span>
                  ` : ''}
                  
                  ${item.dbConfidence ? `
                    <span class="inline-flex items-center px-2 py-1 rounded text-xs ${
                      item.dbConfidence === 'high' ? 'bg-blue-100 text-blue-800' :
                      item.dbConfidence === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                      item.dbConfidence === 'low' ? 'bg-gray-100 text-gray-800' :
                      'bg-red-100 text-red-800'
                    }">
                      ${item.dbConfidence === 'high' ? ' 완전한 정보' :
                        item.dbConfidence === 'medium' ? ' 부분 정보' :
                        item.dbConfidence === 'low' ? ' 제한된 정보' :
                        '정보 없음'}
                    </span>
                  ` : ''}
                  
                  ${item.lastUpdated ? `
                    <span class="text-xs text-gray-500">
                      <i class="fas fa-clock mr-1"></i>
                      ${new Date(item.lastUpdated).toLocaleDateString('ko-KR')} 업데이트
                    </span>
                  ` : ''}
                </div>
                
                <!-- 경고 메시지 -->
                ${item.warning ? `
                  <div class="mt-4 p-3 bg-yellow-50 border-l-4 border-yellow-400 rounded text-sm text-yellow-800 leading-relaxed">
                    <i class="fas fa-exclamation-triangle mr-2"></i>
                    <strong>⚠️ 경고:</strong><br/>
                    <span class="ml-6">${item.warning}</span>
                  </div>
                ` : ''}
              </div>

              ${item.hasData ? `
                <!-- 수술 상세 정보 -->
                ${item.surgery ? `
                  <div class="mb-6 p-5 bg-gray-50 rounded">
                    <h5 class="font-bold text-lg md:text-xl text-gray-900 mb-4 flex items-center">
                      <i class="fas fa-info-circle text-blue-600 mr-2"></i>
                      ■ 수술 기본 정보
                    </h5>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm md:text-base">
                      ${item.surgery.name_en ? `
                        <div class="leading-relaxed">
                          <span class="text-gray-600">✔️ 영문명:</span> 
                          <span class="font-medium">${item.surgery.name_en}</span>
                        </div>
                      ` : ''}
                      ${item.surgery.medical_classification ? `
                        <div class="leading-relaxed">
                          <span class="text-gray-600">✔️ 의학적 분류:</span> 
                          <span class="font-medium">${item.surgery.medical_classification}</span>
                        </div>
                      ` : ''}
                      ${item.surgery.difficulty_level ? `
                        <div class="leading-relaxed">
                          <span class="text-gray-600">✔️ 난이도:</span> 
                          <span class="font-medium">${item.surgery.difficulty_level}종 수술</span>
                        </div>
                      ` : ''}
                    </div>
                  </div>
                ` : ''}

                <!-- 1-5종 수술비 특약 보장 현황 -->
                ${item.typeBenefits && item.typeBenefits.length > 0 ? `
                  <div class="mb-6 p-5 bg-green-50 rounded">
                    <h5 class="font-bold text-lg md:text-xl text-green-900 mb-4 flex items-center">
                      <i class="fas fa-list-ol text-green-600 mr-2"></i>
                      ■ 1-5종 수술비 특약 보장 현황 (${item.typeBenefits.length}개 보험사)
                    </h5>
                    <div class="space-y-3">
                      ${item.typeBenefits.map(benefit => `
                        <div class="bg-white p-3 rounded border-l-4 border-green-500">
                          <div class="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2">
                            <div class="flex-1">
                              <div class="font-semibold text-gray-900 text-base">✔️ ${benefit.company_name}</div>
                              <div class="text-gray-600 text-sm mt-1">(${benefit.surgery_type}종 수술)</div>
                            </div>
                            <div class="text-left sm:text-right">
                              <span class="font-bold text-green-700 text-lg">${benefit.benefit_amount ? formatCurrency(benefit.benefit_amount) : '-'}</span>
                            </div>
                          </div>
                        </div>
                      `).join('')}
                    </div>
                  </div>
                ` : `
                  <div class="mb-6 p-4 bg-gray-100 rounded text-center text-gray-500 text-sm md:text-base">
                    <i class="fas fa-inbox mr-2"></i>
                    등록된 1-5종 특약 정보가 없습니다
                  </div>
                `}

                <!-- N대 수술비 특약 세부등급 보장 현황 -->
                ${item.nBenefits && item.nBenefits.length > 0 ? `
                  <div class="mb-6 p-5 bg-purple-50 rounded">
                    <h5 class="font-bold text-lg md:text-xl text-purple-900 mb-4 flex items-center">
                      <i class="fas fa-hospital text-purple-600 mr-2"></i>
                      ■ N대 수술비 특약 세부등급 보장 현황 (${item.nBenefits.length}개 보험사)
                    </h5>
                    <div class="space-y-3">
                      ${item.nBenefits.map(benefit => `
                        <div class="bg-white p-3 rounded border-l-4 ${benefit.is_covered ? 'border-green-500' : 'border-red-500'}">
                          <div class="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2">
                            <div class="flex-1">
                              <div class="font-semibold text-gray-900 text-base">■ ${benefit.company_name}</div>
                              <div class="text-gray-600 text-sm mt-1">
                                ${benefit.total_n}대 특약
                                ${benefit.sub_category ? ' - ' + benefit.sub_category : ''}
                              </div>
                            </div>
                            <div class="text-left sm:text-right">
                              <div class="${benefit.is_covered ? 'text-green-600' : 'text-red-600'} font-bold mb-1">
                                ${benefit.is_covered ? '✔️ 보장' : '✗ 미보장'}
                              </div>
                              ${benefit.benefit_amount && benefit.is_covered ? `
                                <div class="text-purple-700 font-semibold text-sm">
                                  ${formatCurrency(benefit.benefit_amount)}
                                </div>
                              ` : ''}
                            </div>
                          </div>
                        </div>
                      `).join('')}
                    </div>
                  </div>
                ` : `
                  <div class="mb-6 p-4 bg-gray-100 rounded text-center text-gray-500 text-sm md:text-base">
                    <i class="fas fa-inbox mr-2"></i>
                    등록된 N대 특약 정보가 없습니다
                  </div>
                `}

                <!-- 가능성 정보 (리스크 대비) -->
                ${item.risk ? `
                  <div class="mb-6 p-5 bg-yellow-50 rounded">
                    <h5 class="font-bold text-lg md:text-xl text-yellow-900 mb-4 flex items-center">
                      <i class="fas fa-exclamation-triangle text-yellow-600 mr-2"></i>
                      ■ 가능성 정보 (리스크 대비)
                    </h5>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm md:text-base">
                      ${item.risk.recurrence_risk ? `
                        <div class="leading-relaxed">
                          <span class="text-gray-700 font-semibold">✔️ 재발 가능성:</span>
                          <span class="text-gray-900 ml-2">${item.risk.recurrence_risk}</span>
                        </div>
                      ` : ''}
                      ${item.risk.reoperation_risk ? `
                        <div class="leading-relaxed">
                          <span class="text-gray-700 font-semibold">✔️ 재수술 필요성:</span>
                          <span class="text-gray-900 ml-2">${item.risk.reoperation_risk}</span>
                        </div>
                      ` : ''}
                      ${item.risk.complication_risk ? `
                        <div class="leading-relaxed">
                          <span class="text-gray-700 font-semibold">✔️ 합병증 위험:</span>
                          <span class="text-gray-900 ml-2">${item.risk.complication_risk}</span>
                        </div>
                      ` : ''}
                      ${item.risk.additional_treatment ? `
                        <div class="leading-relaxed">
                          <span class="text-gray-700 font-semibold">✔️ 추가 치료:</span>
                          <span class="text-gray-900 ml-2">${item.risk.additional_treatment}</span>
                        </div>
                      ` : ''}
                    </div>
                    ${item.risk.insurance_notes ? `
                      <div class="mt-4 p-4 bg-yellow-100 rounded text-sm md:text-base">
                        <div class="font-bold text-yellow-900 mb-3 flex items-center">
                          <i class="fas fa-exclamation-triangle mr-2"></i>
                          ⚠️ 보험 청구 주의사항
                        </div>
                        <div class="space-y-3 text-yellow-900 leading-relaxed">
                          ${(() => {
                            // 보험사명 패턴으로 분리 (보험사명 포함)
                            const parts = item.risk.insurance_notes.split(/(\b[가-힣]{2,}(?:화재|해상|손보|손해보험)\b:\s*)/);
                            const results = [];
                            
                            for (let i = 0; i < parts.length; i++) {
                              if (parts[i] && parts[i].match(/\b[가-힣]{2,}(?:화재|해상|손보|손해보험)\b:\s*/)) {
                                // 보험사명 발견
                                const companyName = parts[i].replace(':', '').trim();
                                const content = parts[i + 1] ? parts[i + 1].trim().replace(/특이사항으로는,?\s*/gi, '').trim() : '';
                                
                                if (content) {
                                  results.push(`
                                    <div class="p-3 bg-white rounded border-l-4 border-yellow-500">
                                      <div class="font-bold text-gray-900 mb-2">
                                        ■ ${companyName}
                                      </div>
                                      <div class="text-gray-700 ml-4 leading-relaxed">
                                        ${content}
                                      </div>
                                    </div>
                                  `);
                                }
                                i++; // 다음 content 부분 건너뛰기
                              }
                            }
                            
                            // 만약 분리가 안 되면 전체를 하나로 표시
                            if (results.length === 0) {
                              results.push(`
                                <div class="p-3 bg-white rounded border-l-4 border-yellow-500">
                                  <div class="text-gray-700 leading-relaxed">
                                    ${item.risk.insurance_notes.replace(/특이사항으로는,?\s*/gi, '').trim()}
                                  </div>
                                </div>
                              `);
                            }
                            
                            return results.join('');
                          })()}
                        </div>
                      </div>
                    ` : ''}
                  </div>
                ` : ''}

                <!-- 고객 상담 포인트 -->
                <div class="p-5 bg-blue-50 rounded">
                  <h5 class="font-bold text-lg md:text-xl text-blue-900 mb-4 flex items-center">
                    <i class="fas fa-comments text-blue-600 mr-2"></i>
                    ■ 고객 상담 포인트
                  </h5>
                  <div class="space-y-3 text-sm md:text-base">
                    ${item.typeBenefits && item.typeBenefits.length > 0 ? (() => {
                      const benefitsWithAmount = item.typeBenefits.filter(b => b.benefit_amount);
                      if (benefitsWithAmount.length > 0) {
                        const max = benefitsWithAmount.reduce((prev, curr) => 
                          (curr.benefit_amount || 0) > (prev.benefit_amount || 0) ? curr : prev
                        );
                        const min = benefitsWithAmount.reduce((prev, curr) => 
                          (curr.benefit_amount || Infinity) < (prev.benefit_amount || Infinity) ? curr : prev
                        );
                        return `
                          <div class="flex justify-between p-2 bg-white rounded">
                            <span class="text-gray-700">최고 보장:</span>
                            <span class="font-bold text-green-600">${max.company_name} - ${formatCurrency(max.benefit_amount)}</span>
                          </div>
                          <div class="flex justify-between p-2 bg-white rounded">
                            <span class="text-gray-700">최저 보장:</span>
                            <span class="font-bold text-blue-600">${min.company_name} - ${formatCurrency(min.benefit_amount)}</span>
                          </div>
                        `;
                      }
                      return '';
                    })() : ''}
                    ${item.nBenefits && item.nBenefits.filter(b => b.is_covered).length > 0 ? `
                      <div class="p-2 bg-white rounded">
                        <span class="text-gray-700 font-semibold">N대 특약 보장:</span>
                        <span class="text-purple-600 ml-2">${item.nBenefits.filter(b => b.is_covered).length}개 보험사</span>
                      </div>
                    ` : ''}
                  </div>
                </div>

                <!-- 주의사항 -->
                <div class="mt-6 p-5 bg-red-50 border-l-4 border-red-500 rounded">
                  <h5 class="font-bold text-lg md:text-xl text-red-900 mb-3 flex items-center">
                    <i class="fas fa-exclamation-circle text-red-600 mr-2"></i>
                    ⚠️ 주의사항
                  </h5>
                  <ul class="text-sm md:text-base text-red-800 space-y-2 leading-relaxed">
                    <li>■ 약관은 보험사별로 변경될 수 있으니<br/>계약 전 반드시 최신 약관을 확인하세요</li>
                    <li>■ 면책기간 및 감액기간을<br/>반드시 확인하세요</li>
                    <li>■ 고객의 나이, 건강 상태,<br/>기존 보험 가입 여부에 따라<br/>맞춤 상담이 필요합니다</li>
                  </ul>
                </div>
              ` : `
                <div class="p-5 bg-yellow-50 border-l-4 border-yellow-500 rounded text-sm md:text-base leading-relaxed">
                  <i class="fas fa-exclamation-triangle text-yellow-600 mr-2"></i>
                  <strong>⚠️ 알림:</strong><br/>
                  <span class="ml-6">${item.notice || '데이터베이스에 등록되지 않은 수술입니다.'}</span>
                </div>
              `}
            </div>
          `;
          
          return content;
        }).join('');
      }

      // 결과를 표시할 모달 생성
      const modalDiv = document.createElement('div');
      modalDiv.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-2 sm:p-4 overflow-y-auto';
      modalDiv.innerHTML = `
        <div class="bg-white dark:bg-gray-900 rounded-lg max-w-6xl w-full my-4 sm:my-8 overflow-hidden flex flex-col" style="max-height: 95vh;">
          <div class="p-3 sm:p-6 border-b bg-gradient-to-r from-orange-500 to-orange-600 text-white sticky top-0 z-10">
            <div class="flex items-center justify-between flex-col sm:flex-row gap-2 sm:gap-0">
              <div class="w-full sm:w-auto">
                <h3 class="text-lg sm:text-2xl font-bold flex items-center">
                  <i class="fas fa-robot mr-2 sm:mr-3 text-base sm:text-xl"></i>
                  Studioju_AI 검색결과
                </h3>
                <p class="mt-1 opacity-90 text-xs sm:text-sm">"${query}" | ${result.total || 0}개 결과</p>
              </div>
              <div class="flex gap-2 w-full sm:w-auto">
                <button onclick="downloadAsPDF()" class="flex-1 sm:flex-none px-3 sm:px-4 py-2 bg-white text-orange-600 rounded-lg hover:bg-gray-100 transition-all flex items-center justify-center gap-2 font-bold text-sm">
                  <i class="fas fa-file-pdf"></i>
                  <span class="hidden sm:inline">PDF</span>
                </button>
                <button onclick="downloadAsTXT()" class="flex-1 sm:flex-none px-3 sm:px-4 py-2 bg-white text-orange-600 rounded-lg hover:bg-gray-100 transition-all flex items-center justify-center gap-2 font-bold text-sm">
                  <i class="fas fa-file-alt"></i>
                  <span class="hidden sm:inline">TXT</span>
                </button>
              </div>
            </div>
          </div>
          
          <div class="overflow-y-auto flex-1 p-3 sm:p-6 bg-white dark:bg-gray-900">
            ${result.answer ? `
              <div class="bg-blue-50 border-l-4 border-blue-500 p-3 sm:p-4 mb-4 sm:mb-6 rounded">
                <div class="flex items-start">
                  <i class="fas fa-lightbulb text-blue-500 text-lg sm:text-xl mt-1 mr-2 sm:mr-3 flex-shrink-0"></i>
                  <div class="text-gray-700 w-full" style="font-size: 14px; line-height: 1.8;">
                    <div class="whitespace-pre-wrap break-words" style="word-break: break-word; overflow-wrap: break-word;">
                      ${result.answer}
                    </div>
                  </div>
                </div>
              </div>
            ` : ''}
            
            ${resultsHTML || `
              <div class="text-center py-12 text-gray-500">
                <i class="fas fa-search text-6xl mb-4"></i>
                <p class="text-xl">검색 결과가 없습니다.</p>
              </div>
            `}
            
            <div class="mt-4 sm:mt-6 p-3 sm:p-4 bg-gray-50 rounded-lg text-xs text-gray-600">
              <i class="fas fa-robot mr-2"></i>
              AI 기반 검색 결과이므로 참고용으로만 사용하시고, 정확한 정보는 전문가와 상담하세요.
            </div>
          </div>
          
          <div class="p-3 sm:p-6 border-t bg-gray-50 sticky bottom-0">
            <div class="flex gap-2 sm:gap-3 flex-col sm:flex-row">
              <button onclick="downloadResultsAsTxt(${JSON.stringify(result.results).replace(/"/g, '&quot;')}, '${query.replace(/'/g, "\\'")}')"
                      class="flex-1 bg-green-600 text-white px-4 sm:px-6 py-2.5 sm:py-3 rounded-lg hover:bg-green-700 font-semibold transition-colors shadow-md text-sm sm:text-base">
                <i class="fas fa-download mr-2"></i>TXT 다운로드
              </button>
              <button onclick="this.closest('.fixed').remove()" 
                      class="flex-1 bg-orange-600 text-white px-4 sm:px-6 py-2.5 sm:py-3 rounded-lg hover:bg-orange-700 font-semibold transition-colors shadow-md text-sm sm:text-base">
                <i class="fas fa-check mr-2"></i>확인
              </button>
            </div>
          </div>
        </div>
      `;
      document.body.appendChild(modalDiv);

      // 모달 외부 클릭 시 닫기
      modalDiv.addEventListener('click', (e) => {
        if (e.target === modalDiv) {
          modalDiv.remove();
        }
      });
    } else {
      alert(` GPT 검색 실패\n\n오류: ${result.error || '알 수 없는 오류'}`);
    }
  } catch (error) {
    if (document.getElementById('gpt-search-loading')) {
      document.body.removeChild(loadingDiv);
    }
    
    console.error('GPT search error:', error);
    alert(' GPT 검색 중 오류가 발생했습니다.\n\n' + error.message);
  }
}

/**
 * 검색 결과를 TXT 파일로 다운로드
 */
function downloadResultsAsTxt(results, query) {
  if (!results || results.length === 0) {
    alert('다운로드할 검색 결과가 없습니다.');
    return;
  }

  // TXT 형식으로 변환
  let txtContent = `=================================================\n`;
  txtContent += `    Studioju_AI 보험 수술 검색 결과\n`;
  txtContent += `=================================================\n\n`;
  txtContent += `검색어: ${query}\n`;
  txtContent += `검색 일시: ${new Date().toLocaleString('ko-KR')}\n`;
  txtContent += `총 결과: ${results.length}개\n\n`;
  txtContent += `=================================================\n\n`;

  results.forEach((item, index) => {
    const circleNum = ['❶', '❷', '❸', '❹', '❺', '❻'][index] || `⓪${index + 1}`;
    
    txtContent += `${circleNum} ${item.name || '수술명 없음'}\n`;
    txtContent += `${'='.repeat(50)}\n\n`;
    
    // 기본 정보
    txtContent += `■ 기본 정보\n`;
    txtContent += `  코드: ${item.code || 'N/A'}\n`;
    if (item.description) {
      txtContent += `  설명: ${item.description}\n`;
    }
    if (item.surgery) {
      if (item.surgery.name_en) txtContent += `  영문명: ${item.surgery.name_en}\n`;
      if (item.surgery.medical_classification) txtContent += `  의학적 분류: ${item.surgery.medical_classification}\n`;
      if (item.surgery.difficulty_level) txtContent += `  난이도: ${item.surgery.difficulty_level}종 수술\n`;
    }
    txtContent += `\n`;

    // 데이터 출처
    txtContent += `■ 데이터 출처\n`;
    if (item.dataSource === 'database') {
      txtContent += `  ✔️ 데이터베이스 (높은 신뢰도)\n`;
    } else if (item.dataSource === 'gpt') {
      txtContent += `  ✔️ AI 검색 (참고용)\n`;
    }
    if (item.dbConfidence) {
      const conf = item.dbConfidence === 'high' ? ' 완전한 정보' :
                   item.dbConfidence === 'medium' ? ' 부분 정보' :
                   item.dbConfidence === 'low' ? ' 제한된 정보' : '정보 없음';
      txtContent += `  신뢰도: ${conf}\n`;
    }
    if (item.lastUpdated) {
      txtContent += `  업데이트: ${new Date(item.lastUpdated).toLocaleDateString('ko-KR')}\n`;
    }
    txtContent += `\n`;

    // 1-5종 수술비 특약
    if (item.typeBenefits && item.typeBenefits.length > 0) {
      txtContent += `■ 1-5종 수술비 특약 보장 현황 (${item.typeBenefits.length}개 보험사)\n`;
      item.typeBenefits.forEach(benefit => {
        const amount = benefit.benefit_amount ? formatCurrency(benefit.benefit_amount) : '-';
        txtContent += `  ✔️ ${benefit.company_name} (${benefit.surgery_type}종): ${amount}\n`;
      });
      txtContent += `\n`;
    } else {
      txtContent += `■ 1-5종 수술비 특약\n`;
      txtContent += `  등록된 정보가 없습니다\n\n`;
    }

    // N대 수술비 특약
    if (item.nBenefits && item.nBenefits.length > 0) {
      txtContent += `■ N대 수술비 특약 세부등급 보장 현황 (${item.nBenefits.length}개 보험사)\n`;
      item.nBenefits.forEach(benefit => {
        const covered = benefit.is_covered ? '✔️ 보장' : '✗ 미보장';
        const amount = benefit.benefit_amount ? ` (${formatCurrency(benefit.benefit_amount)})` : '';
        const sub = benefit.sub_category ? ` - ${benefit.sub_category}` : '';
        txtContent += `  ${covered}: ${benefit.company_name} ${benefit.total_n}대 특약${sub}${amount}\n`;
      });
      txtContent += `\n`;
    } else {
      txtContent += `■ N대 수술비 특약\n`;
      txtContent += `  등록된 정보가 없습니다\n\n`;
    }

    // 가능성 정보 (리스크)
    if (item.risk) {
      txtContent += `■ 가능성 정보 (리스크 대비)\n`;
      if (item.risk.recurrence_risk) txtContent += `  재발 가능성: ${item.risk.recurrence_risk}\n`;
      if (item.risk.reoperation_risk) txtContent += `  재수술 필요성: ${item.risk.reoperation_risk}\n`;
      if (item.risk.complication_risk) txtContent += `  합병증 위험: ${item.risk.complication_risk}\n`;
      if (item.risk.additional_treatment) txtContent += `  추가 치료: ${item.risk.additional_treatment}\n`;
      if (item.risk.insurance_notes) txtContent += `  보험 청구 주의사항: ${item.risk.insurance_notes}\n`;
      txtContent += `\n`;
    }

    // 경고 메시지
    if (item.warning) {
      txtContent += `⚠️ 경고: ${item.warning}\n\n`;
    }

    txtContent += `\n`;
  });

  // 주의사항
  txtContent += `=================================================\n`;
  txtContent += `주의사항\n`;
  txtContent += `=================================================\n\n`;
  txtContent += `• 약관은 보험사별로 변경될 수 있으니 계약 전 반드시 최신 약관을 확인하세요\n`;
  txtContent += `• 면책기간 및 감액기간을 반드시 확인하세요\n`;
  txtContent += `• 고객의 나이, 건강 상태, 기존 보험 가입 여부에 따라 맞춤 상담이 필요합니다\n`;
  txtContent += `• AI 기반 검색 결과이므로 참고용으로만 사용하시고, 정확한 정보는 전문가와 상담하세요\n\n`;

  txtContent += `=================================================\n`;
  txtContent += `생성: Studioju_AI 보험 수술 검색 시스템\n`;
  txtContent += `=================================================\n`;

  // Blob 생성 및 다운로드
  const blob = new Blob([txtContent], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  const timestamp = new Date().toISOString().split('T')[0];
  link.download = `Studioju_AI_검색결과_${query.substring(0, 10)}_${timestamp}.txt`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);

  // 다운로드 완료 알림
  const notification = document.createElement('div');
  notification.className = 'fixed bottom-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in';
  notification.innerHTML = '<i class="fas fa-check-circle mr-2"></i>TXT 파일이 다운로드되었습니다!';
  document.body.appendChild(notification);
  setTimeout(() => {
    notification.remove();
  }, 3000);
}

// ==================== 보험기관 링크 ====================

let organizationsData = null;

// 페이지 로드 시 보험기관 데이터 불러오기
document.addEventListener('DOMContentLoaded', () => {
  loadOrganizations();
});

async function loadOrganizations() {
  try {
    const response = await fetch('/static/organizations.json');
    organizationsData = await response.json();
    
    // 카운트 표시
    document.getElementById('insuranceCount').textContent = `(${organizationsData.insurance_orgs.length})`;
    document.getElementById('relatedCount').textContent = `(${organizationsData.related_orgs.length})`;
    document.getElementById('overseasCount').textContent = `(${organizationsData.overseas_orgs.length})`;
    
  } catch (error) {
    console.error('Failed to load organizations:', error);
  }
}

function toggleOrgSection(type) {
  const sectionMap = {
    'insurance': {
      container: document.getElementById('insuranceOrgs'),
      chevron: document.getElementById('insuranceChevron'),
      data: organizationsData?.insurance_orgs || []
    },
    'related': {
      container: document.getElementById('relatedOrgs'),
      chevron: document.getElementById('relatedChevron'),
      data: organizationsData?.related_orgs || []
    },
    'overseas': {
      container: document.getElementById('overseasOrgs'),
      chevron: document.getElementById('overseasChevron'),
      data: organizationsData?.overseas_orgs || []
    }
  };
  
  const section = sectionMap[type];
  if (!section) return;
  
  const isHidden = section.container.classList.contains('hidden');
  
  if (isHidden) {
    // 열기
    section.container.classList.remove('hidden');
    section.chevron.classList.add('rotate-180');
    
    // 데이터가 아직 렌더링되지 않았으면 렌더링
    if (section.container.children.length === 0) {
      renderOrganizations(section.container, section.data);
    }
  } else {
    // 닫기
    section.container.classList.add('hidden');
    section.chevron.classList.remove('rotate-180');
  }
}

function renderOrganizations(container, orgs) {
  container.innerHTML = orgs.map(org => `
    <a href="${org.url}" target="_blank" rel="noopener noreferrer" 
       class="block p-2 rounded hover:bg-gray-50 transition-colors group">
      <div class="flex items-center justify-between">
        <span class="text-sm text-gray-700 group-hover:text-blue-600">${org.name}</span>
        <i class="fas fa-external-link-alt text-xs text-gray-400 group-hover:text-blue-500"></i>
      </div>
      <div class="text-xs text-gray-500 mt-1">${org.url.replace('https://', '').replace('http://', '')}</div>
    </a>
  `).join('');
}

// ==================== PDF 업로드 및 분석 ====================

/**
 * PDF 업로드 모달 열기
 */
function showPDFUpload() {
  const modal = document.getElementById('pdfUploadModal');
  if (modal) {
    modal.classList.remove('hidden');
  }
}

/**
 * PDF 업로드 모달 닫기
 */
function closePDFUpload() {
  const modal = document.getElementById('pdfUploadModal');
  if (modal) {
    modal.classList.add('hidden');
    // 입력 필드 초기화
    document.getElementById('insuranceCompanySelect').value = '';
    document.getElementById('pdfFileInput').value = '';
    document.getElementById('pdfAnalysisProgress').classList.add('hidden');
    document.getElementById('pdfAnalysisResult').classList.add('hidden');
  }
}

/**
 * PDF 업로드 및 분석 시작
 */
async function uploadAndAnalyzePDF() {
  const companySelect = document.getElementById('insuranceCompanySelect');
  const fileInput = document.getElementById('pdfFileInput');
  const progressDiv = document.getElementById('pdfAnalysisProgress');
  const statusDiv = document.getElementById('pdfAnalysisStatus');
  const resultDiv = document.getElementById('pdfAnalysisResult');

  const company = companySelect.value;
  const file = fileInput.files?.[0];

  if (!company) {
    alert(' 보험사를 선택해주세요');
    return;
  }

  if (!file) {
    alert(' PDF 파일을 선택해주세요');
    return;
  }

  if (!file.name.toLowerCase().endsWith('.pdf')) {
    alert(' PDF 파일만 업로드 가능합니다');
    return;
  }

  // 진행 상태 표시
  progressDiv.classList.remove('hidden');
  resultDiv.classList.add('hidden');
  resultDiv.innerHTML = '';

  try {
    // 1단계: 파일 업로드
    statusDiv.textContent = ` PDF 파일 업로드 중... (${(file.size / 1024 / 1024).toFixed(2)} MB)`;

    const formData = new FormData();
    formData.append('company', company);
    formData.append('file', file);

    // 2단계: GPT-4 분석
    statusDiv.textContent = ' GPT-4가 PDF를 분석하는 중... (1-2분 소요)';

    const response = await fetch('/api/admin/analyze-pdf', {
      method: 'POST',
      body: formData
    });

    const result = await response.json();

    progressDiv.classList.add('hidden');

    if (!result.success) {
      throw new Error(result.error || '알 수 없는 오류');
    }

    // 3단계: 결과 표시
    displayPDFAnalysisResult(result.data);

    // 4단계: JSON 저장 확인
    if (confirm(`✔️ 분석 완료!\n\n${result.itemCount}개의 항목을 추출했습니다.\n\ndiagnosis-codes.json에 보험 정보를 추가하시겠습니까?`)) {
      await savePDFDataToJSON(result.data);
    }

  } catch (error) {
    progressDiv.classList.add('hidden');
    console.error('PDF 분석 오류:', error);
    alert(` PDF 분석 실패\n\n${error.message}`);
  }
}

/**
 * PDF 분석 결과 표시
 */
function displayPDFAnalysisResult(data) {
  const resultDiv = document.getElementById('pdfAnalysisResult');

  let html = `
    <div class="bg-green-50 border-l-4 border-green-500 p-4 rounded mb-4">
      <h4 class="font-bold text-green-900 mb-2">
        <i class="fas fa-check-circle mr-2"></i>분석 완료!
      </h4>
      <div class="text-green-800 space-y-1">
        <p><strong>보험사:</strong> ${data.company}</p>
        <p><strong>전체 N대:</strong> ${data.total_n}</p>
        <p><strong>추출 항목:</strong> ${data.items?.length || 0}개</p>
      </div>
    </div>

    <div class="bg-white border rounded-lg p-4 max-h-96 overflow-y-auto">
      <h5 class="font-bold text-gray-900 mb-3">추출된 항목 목록</h5>
      <div class="space-y-2">
        ${data.items?.slice(0, 50).map((item, index) => `
          <div class="border-b pb-2 text-sm">
            <div class="font-semibold text-gray-900">${index + 1}. ${item.name}</div>
            <div class="text-gray-600 mt-1">
              <span class="bg-blue-100 text-blue-800 px-2 py-0.5 rounded text-xs font-mono">${item.code}</span>
              ${item.n_grade ? `<span class="ml-2 bg-purple-100 text-purple-800 px-2 py-0.5 rounded text-xs">${item.n_grade}</span>` : ''}
              ${item.type_1to5 ? `<span class="ml-2 bg-green-100 text-green-800 px-2 py-0.5 rounded text-xs">${item.type_1to5}종</span>` : ''}
            </div>
          </div>
        `).join('')}
        ${(data.items?.length || 0) > 50 ? `
          <div class="text-center text-gray-500 text-sm py-2">
            ... 외 ${data.items.length - 50}개 항목 더 있음
          </div>
        ` : ''}
      </div>
    </div>
  `;

  resultDiv.innerHTML = html;
  resultDiv.classList.remove('hidden');
}

/**
 * PDF 분석 데이터를 JSON 파일에 저장
 */
async function savePDFDataToJSON(data) {
  try {
    // 현재 diagnosis-codes.json 로드
    const response = await fetch('/static/diagnosis-codes.json');
    const currentData = await response.json();

    // 새로운 보험 정보 추가
    const updatedData = currentData.map(item => {
      // PDF에서 추출한 데이터와 매칭
      const match = data.items?.find(pdfItem => 
        pdfItem.code === item.code || 
        pdfItem.name.includes(item.name) || 
        item.name.includes(pdfItem.name)
      );

      if (match) {
        return {
          ...item,
          insurance: {
            ...(item.insurance || {}),
            [`${data.company}_${data.total_n}`]: match.n_grade,
            ...(match.type_1to5 ? { type_1to5: match.type_1to5 } : {})
          }
        };
      }

      return item;
    });

    // 새로운 코드 추가 (기존에 없는 경우)
    const newCodes = data.items?.filter(pdfItem => 
      !currentData.some(item => item.code === pdfItem.code)
    ).map(pdfItem => ({
      code: pdfItem.code,
      name: pdfItem.name,
      category: '추후 분류 필요',
      chapter: pdfItem.code.charAt(0) + '00-' + pdfItem.code.charAt(0) + '99',
      section: '',
      description: '',
      insurance: {
        [`${data.company}_${data.total_n}`]: pdfItem.n_grade,
        ...(pdfItem.type_1to5 ? { type_1to5: pdfItem.type_1to5 } : {})
      }
    }));

    const finalData = [...updatedData, ...newCodes];

    // JSON 다운로드 (수동 저장)
    const blob = new Blob([JSON.stringify(finalData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'diagnosis-codes-updated.json';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    alert(`✔️ JSON 파일이 다운로드되었습니다!\n\n파일명: diagnosis-codes-updated.json\n\n이 파일을 /public/static/diagnosis-codes.json 으로 교체해주세요.`);

    // 모달 닫기
    closePDFUpload();

  } catch (error) {
    console.error('JSON 저장 오류:', error);
    alert(` JSON 저장 실패\n\n${error.message}`);
  }
}

// ==================== 프로젝트 모달 ====================

function openProjectModal(url, title) {
  const modal = document.getElementById('projectModal');
  const iframe = document.getElementById('projectIframe');
  const titleElement = document.getElementById('projectModalTitle');
  
  if (modal && iframe && titleElement) {
    titleElement.textContent = title;
    iframe.src = url;
    modal.classList.remove('hidden');
    
    // ESC 키로 닫기
    document.addEventListener('keydown', handleProjectModalEscape);
  }
}

function closeProjectModal() {
  const modal = document.getElementById('projectModal');
  const iframe = document.getElementById('projectIframe');
  
  if (modal && iframe) {
    modal.classList.add('hidden');
    iframe.src = '';
    
    // ESC 키 이벤트 제거
    document.removeEventListener('keydown', handleProjectModalEscape);
  }
}

function handleProjectModalEscape(event) {
  if (event.key === 'Escape') {
    closeProjectModal();
  }
}

// 모달 외부 클릭 시 닫기
document.addEventListener('DOMContentLoaded', () => {
  const modal = document.getElementById('projectModal');
  if (modal) {
    modal.addEventListener('click', (event) => {
      if (event.target === modal) {
        closeProjectModal();
      }
    });
  }
});

/**
 * PDF 다운로드 기능
 * jsPDF 라이브러리를 동적으로 로드하여 검색 결과를 PDF로 변환
 */
async function downloadAsPDF() {
  const resultsDiv = document.getElementById('results');
  if (!resultsDiv || !resultsDiv.innerHTML.trim()) {
    alert('다운로드할 검색 결과가 없습니다.');
    return;
  }

  try {
    // jsPDF 라이브러리 동적 로드
    if (typeof window.jspdf === 'undefined') {
      const script = document.createElement('script');
      script.src = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';
      document.head.appendChild(script);
      
      await new Promise((resolve, reject) => {
        script.onload = resolve;
        script.onerror = reject;
      });
    }

    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    // PDF 내용 생성
    const content = resultsDiv.innerText;
    const lines = content.split('\n').filter(line => line.trim());
    
    let y = 20;
    const pageHeight = doc.internal.pageSize.height;
    const margin = 20;
    const lineHeight = 7;

    // 제목
    doc.setFontSize(16);
    doc.text('보험 수술비 특약 분석 결과', margin, y);
    y += 15;

    // 생성일시
    doc.setFontSize(10);
    doc.text(`생성일시: ${new Date().toLocaleString('ko-KR')}`, margin, y);
    y += 10;

    // 본문
    doc.setFontSize(10);
    lines.forEach((line, index) => {
      // 페이지 넘김 체크
      if (y > pageHeight - margin) {
        doc.addPage();
        y = margin;
      }

      // 긴 텍스트 줄바꿈 처리
      const maxWidth = doc.internal.pageSize.width - 2 * margin;
      const splitText = doc.splitTextToSize(line, maxWidth);
      
      splitText.forEach((textLine) => {
        if (y > pageHeight - margin) {
          doc.addPage();
          y = margin;
        }
        doc.text(textLine, margin, y);
        y += lineHeight;
      });
    });

    // 파일명 생성
    const timestamp = new Date().toISOString().slice(0, 10);
    const filename = `보험분석_${timestamp}.pdf`;

    // PDF 다운로드
    doc.save(filename);
    
    console.log('✔️ PDF 다운로드 완료:', filename);
  } catch (error) {
    console.error(' PDF 생성 오류:', error);
    alert('PDF 생성 중 오류가 발생했습니다.');
  }
}

/**
 * TXT 다운로드 기능
 * 검색 결과를 텍스트 파일로 다운로드
 */
function downloadAsTXT() {
  const resultsDiv = document.getElementById('results');
  if (!resultsDiv || !resultsDiv.innerHTML.trim()) {
    alert('다운로드할 검색 결과가 없습니다.');
    return;
  }

  try {
    const content = resultsDiv.innerText;
    const header = `보험 수술비 특약 분석 결과\n생성일시: ${new Date().toLocaleString('ko-KR')}\n${'='.repeat(60)}\n\n`;
    const fullContent = header + content;

    const blob = new Blob([fullContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    
    const timestamp = new Date().toISOString().slice(0, 10);
    a.download = `보험분석_${timestamp}.txt`;
    
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    console.log('✔️ TXT 다운로드 완료');
  } catch (error) {
    console.error(' TXT 생성 오류:', error);
    alert('텍스트 파일 생성 중 오류가 발생했습니다.');
  }
}
